package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import static ec.edu.espe.electromechanicalmaintenancemanagementsystem.model.ConsoleOutput.show;

import java.util.Arrays;


public class ClientActions {
    private final SystemState state;
    private final UserInput input;

    public ClientActions(SystemState state, UserInput input) {
        this.state = state;
        this.input = input;
    }

    public void register() {
        String name = input.readName("Client name (letters only): ");
        String contact = input.readPhone("Contact information (10 digits starting with 0): ");
        String address = input.readText("Address: ");
        Client client = new Client(state.nextClientId(), name, contact, address);
        state.clients.add(client);
        System.out.println("Client saved to data/clients.json.");
        System.out.println(client);
    }

    public void removeEquipment() {
        show(state.clients);
        Client client = state.findClient(input.readInt("Client ID: "));
        if (client == null) {
            System.out.println("Client not found.");
            return;
        }
        show(Arrays.asList(client.getEquipmentList()));
        int equipmentId = input.readInt("Equipment ID to remove from client: ");
        if (!client.ownsEquipment(equipmentId)) {
            System.out.println("That equipment is not assigned to the selected client.");
            return;
        }
        client.removeEquipment(equipmentId);
        System.out.println("Equipment association removed from this client. The equipment record remains in the system.");
        System.out.println("Updated client equipment list:");
        show(Arrays.asList(client.getEquipmentList()));
    }

    public void editOrDelete() {
        if (state.clients.isEmpty()) {
            System.out.println("No clients registered.");
            return;
        }
        System.out.println("1. Correct a client's name");
        System.out.println("2. Delete a client completely");
        int action = input.readIntInRange("Choose: ", 1, 2);
        show(state.clients);
        Client selected = state.findClient(input.readPositiveInt("Client ID: "));
        if (selected == null) {
            System.out.println("Client not found.");
            return;
        }
        if (action == 1) {
            selected.setName(input.readName("Corrected client name: "));
            System.out.println("Client name updated and saved.");
        } else {
            deleteClient(selected);
        }
    }

    public void updateContact() {
        show(state.clients);
        Client client = state.findClient(input.readPositiveInt("Client ID: "));
        if (client == null) {
            System.out.println("Client not found.");
            return;
        }
        client.setName(input.readName("Client name: "));
        client.setContactInfo(input.readPhone("Contact phone: "));
        client.setAddress(input.readText("Address: "));
        System.out.println("Client information updated.");
    }

    private void deleteClient(Client client) {
        if (input.readBoolean("Confirm permanent deletion (yes/no): ")) {
            state.clients.remove(client);
            System.out.println("Client deleted from data/clients.json.");
            System.out.println("Note: the client's equipment records are not automatically deleted.");
        } else {
            System.out.println("Deletion cancelled.");
        }
    }
}
