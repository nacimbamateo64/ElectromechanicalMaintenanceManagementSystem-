package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.List;
import java.util.Locale;

/**
 * Console action for the unified search (menu option 17).
 * POLYMORPHISM: clients, equipment, technicians and work orders are all searched through
 * the Searchable interface, so no matching logic is repeated here.
 */
public class SearchActions {
    private final SystemState state;
    private final UserInput input;

    public SearchActions(SystemState state, UserInput input) {
        this.state = state;
        this.input = input;
    }

    public void search() {
        System.out.println("1. Search client by ID or name");
        System.out.println("2. Search equipment by ID, name or serial number");
        System.out.println("3. Search technician by ID, name or expertise");
        System.out.println("4. Search work order by ID, description, service or status");
        int searchType = input.readIntInRange("Choose: ", 1, 4);
        String term = input.readText("Search term: ").toLowerCase(Locale.ROOT);
        switch (searchType) {
            case 1: showMatches(Searchable.filter(state.clients, term)); break;
            case 2: showEquipmentMatches(Searchable.filter(state.equipments, term)); break;
            case 3: showMatches(Searchable.filter(state.technicians, term)); break;
            default: showMatches(Searchable.filter(state.orders, term));
        }
    }

    private void showMatches(List<? extends Searchable> matches) {
        if (matches.isEmpty()) {
            System.out.println("No matches found.");
            return;
        }
        for (Searchable match : matches) {
            System.out.println(match);
        }
    }

    private void showEquipmentMatches(List<Equipment> matches) {
        if (matches.isEmpty()) {
            System.out.println("No matches found.");
            return;
        }
        for (Equipment equipment : matches) {
            System.out.println(equipment);
            for (Client client : state.clients) {
                if (client.ownsEquipment(equipment.getEquipmentId())) {
                    System.out.println("Client: " + client.getName() + " (ID " + client.getClientId() + ")");
                }
            }
        }
    }
}
