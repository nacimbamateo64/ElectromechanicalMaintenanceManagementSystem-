package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * ABSTRACTION + INHERITANCE: base class of every service in the price catalogue.
 * Subclasses: PreventiveService, CorrectiveService, DiagnosticService, EmergencyService.
 * POLYMORPHISM: getCategory(), getDefaultPriority() and getTaskType() are abstract;
 * requiresImmediateAttention() is overridden by EmergencyService.
 */
public abstract class MaintenanceService implements Identifiable, Priceable, java.io.Serializable {
    private final int serviceId;
    private final String serviceName;
    private final BigDecimal basePrice;

    protected MaintenanceService(int serviceId, String serviceName, String basePrice) {
        if (serviceId <= 0) {
            throw new IllegalArgumentException("Service ID must be positive.");
        }
        BigDecimal price;
        try {
            price = new BigDecimal(basePrice).setScale(2, RoundingMode.UNNECESSARY);
        } catch (ArithmeticException | NumberFormatException | NullPointerException exception) {
            throw new IllegalArgumentException("Price must be a number with at most 2 decimals: " + basePrice);
        }
        if (price.signum() < 0) {
            throw new IllegalArgumentException("Price must not be negative.");
        }
        this.serviceId = serviceId;
        this.serviceName = serviceName;
        this.basePrice = price;
    }

    @Override
    public int getId() {
        return serviceId;
    }

    public int getServiceId() {
        return serviceId;
    }

    public String getServiceName() {
        return serviceName;
    }

    public BigDecimal getBasePrice() {
        return basePrice;
    }

    /** Exact catalogue price in USD (2 decimals). */
    @Override
    public BigDecimal calculatePrice() {
        return basePrice;
    }

    public abstract String getCategory();

    public abstract String getDefaultPriority();

    public abstract String getTaskType();

    /** Overridden only by services that must be attended immediately. */
    public boolean requiresImmediateAttention() {
        return false;
    }

    public String describe() {
        return String.format("[%s] %s - %s (suggested priority: %s)",
                getCategory(), serviceName, getFormattedPrice(), getDefaultPriority());
    }

    public boolean belongsToCategory(String category) {
        return getCategory().equalsIgnoreCase(category);
    }

    public boolean costsMoreThan(BigDecimal amount) {
        return basePrice.compareTo(amount) > 0;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "{serviceId=" + serviceId + ", serviceName=" + serviceName
                + ", category=" + getCategory() + ", price=" + basePrice.toPlainString() + "}";
    }
}
