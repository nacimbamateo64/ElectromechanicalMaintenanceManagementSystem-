package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

/** POLYMORPHISM: implements Priceable; its price is unitCost x stockQuantity. */
public class Part implements Identifiable, Priceable, Searchable, java.io.Serializable {
    private int partId;
    private String name;
    private int stockQuantity;
    private float unitCost;
    private String supplier;

    public Part(int partId, String name, int stockQuantity, float unitCost, String supplier) {
        this.partId = partId;
        this.name = name;
        this.stockQuantity = stockQuantity;
        this.unitCost = unitCost;
        this.supplier = supplier;
    }

    @Override
    public int getId() {
        return partId;
    }

    public int getPartId() {
        return partId;
    }
    public void setPartId(int partId) {
        this.partId = partId;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getStockQuantity() {
        return stockQuantity;
    }
    public void setStockQuantity(int stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    public float getUnitCost() {
        return unitCost;
    }
    public void setUnitCost(float unitCost) {
        this.unitCost = unitCost;
    }

    public String getSupplier() {
        return supplier;
    }
    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    /** Total value of this part in stock: unitCost x stockQuantity, exact to 2 decimals. */
    @Override
    public java.math.BigDecimal calculatePrice() {
        return new java.math.BigDecimal(Float.toString(unitCost))
                .multiply(java.math.BigDecimal.valueOf(stockQuantity))
                .setScale(2, java.math.RoundingMode.HALF_UP);
    }

    /** Matches by ID, name or supplier. */
    @Override
    public boolean matchesSearchTerm(String term) {
        String normalizedTerm = term.toLowerCase(java.util.Locale.ROOT);
        return String.valueOf(partId).equals(normalizedTerm)
                || Searchable.containsIgnoreCase(name, normalizedTerm)
                || Searchable.containsIgnoreCase(supplier, normalizedTerm);
    }

    public boolean isInStock() {
        return stockQuantity > 0;
    }

    public boolean hasLowStock(int threshold) {
        return stockQuantity <= threshold;
    }

    public void increaseStock(int quantity) {
        requirePositive(quantity);
        stockQuantity += quantity;
    }

    public void decreaseStock(int quantity) {
        requirePositive(quantity);
        if (quantity > stockQuantity) {
            throw new IllegalArgumentException("Not enough stock of " + name + ".");
        }
        stockQuantity -= quantity;
    }

    private static void requirePositive(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive.");
        }
    }

    @Override
    public String toString() {
        return "Part{" + "partId=" + partId + ", " + "name=" + name + ", " + "stockQuantity=" + stockQuantity + ", " + "unitCost=" + unitCost + ", " + "supplier=" + supplier + "}";
    }
}
