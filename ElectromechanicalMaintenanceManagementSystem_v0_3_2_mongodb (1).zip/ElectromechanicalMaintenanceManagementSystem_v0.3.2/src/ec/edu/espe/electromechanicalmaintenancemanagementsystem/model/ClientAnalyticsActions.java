package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.List;
import java.util.Optional;

/** Console actions that show the client spending reports. */
public class ClientAnalyticsActions {
    private final ClientSpendingAnalyzer analyzer;

    public ClientAnalyticsActions(SystemState state) {
        this.analyzer = new ClientSpendingAnalyzer(state);
    }

    public void showSpendingPerClient() {
        System.out.println("\nTOTAL SPENT PER CLIENT (USD)");
        List<ClientSpending> summaries = analyzer.summarizeSpendingByClient();
        ConsoleOutput.show(summaries);
        System.out.println("Total revenue: $" + analyzer.calculateTotalRevenue().toPlainString());
    }

    public void showAverages() {
        System.out.println("\nAVERAGES");
        System.out.println("Average price per work order: $" + analyzer.calculateAverageOrderPrice().toPlainString());
        System.out.println("Average spent per client: $" + analyzer.calculateAverageSpentPerClient().toPlainString());
        System.out.printf("Average purchases per client: %.2f%n", analyzer.calculateAveragePurchasesPerClient());
    }

    public void showLoyaltyGiftRecipient() {
        System.out.println("\nLOYALTY GIFT");
        Optional<ClientSpending> mostFrequent = analyzer.findMostFrequentClient();
        if (!mostFrequent.isPresent()) {
            System.out.println("No client has made a purchase yet.");
            return;
        }
        System.out.println("The client who buys the most often is:");
        System.out.println(mostFrequent.get());
    }
}
