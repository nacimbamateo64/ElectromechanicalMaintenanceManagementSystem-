package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Immutable summary of what one client has bought: how many purchases and how much money. */
public final class ClientSpending {
    private static final int MONEY_SCALE = 2;

    private final Client client;
    private final int purchaseCount;
    private final BigDecimal totalSpent;

    public ClientSpending(Client client, int purchaseCount, BigDecimal totalSpent) {
        this.client = client;
        this.purchaseCount = purchaseCount;
        this.totalSpent = totalSpent.setScale(MONEY_SCALE, RoundingMode.HALF_UP);
    }

    public Client getClient() {
        return client;
    }

    public int getPurchaseCount() {
        return purchaseCount;
    }

    public BigDecimal getTotalSpent() {
        return totalSpent;
    }

    public boolean hasPurchases() {
        return purchaseCount > 0;
    }

    public BigDecimal calculateAveragePerPurchase() {
        if (!hasPurchases()) {
            return BigDecimal.ZERO.setScale(MONEY_SCALE);
        }
        return totalSpent.divide(BigDecimal.valueOf(purchaseCount), MONEY_SCALE, RoundingMode.HALF_UP);
    }

    @Override
    public String toString() {
        return String.format("%s (ID %d) | purchases: %d | total spent: $%s | average per purchase: $%s",
                client.getName(), client.getClientId(), purchaseCount,
                totalSpent.toPlainString(), calculateAveragePerPurchase().toPlainString());
    }
}
