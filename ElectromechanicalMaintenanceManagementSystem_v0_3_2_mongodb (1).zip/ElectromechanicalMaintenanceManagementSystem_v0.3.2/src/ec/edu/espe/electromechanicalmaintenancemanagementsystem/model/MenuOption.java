package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

/** One numbered entry of the main menu: what is shown and what it runs. */
public final class MenuOption {
    private final int number;
    private final String title;
    private final MenuAction action;

    public MenuOption(int number, String title, MenuAction action) {
        if (number <= 0) {
            throw new IllegalArgumentException("Menu option number must be positive.");
        }
        if (title == null || title.isBlank() || action == null) {
            throw new IllegalArgumentException("Menu option needs a title and an action.");
        }
        this.number = number;
        this.title = title;
        this.action = action;
    }

    public int number() {
        return number;
    }

    public String title() {
        return title;
    }

    public void run() {
        action.execute();
    }

    /** Text shown in the menu, for example "5. Create work order". */
    public String label() {
        return number + ". " + title;
    }
}
