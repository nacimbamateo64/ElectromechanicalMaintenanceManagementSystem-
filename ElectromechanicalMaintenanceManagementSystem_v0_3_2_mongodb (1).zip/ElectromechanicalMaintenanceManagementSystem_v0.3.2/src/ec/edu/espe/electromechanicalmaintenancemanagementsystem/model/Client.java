package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.ArrayList;
import java.util.List;

/** INHERITANCE: a Client is a Person. POLYMORPHISM: overrides getRole() and getDetails(). */
public class Client extends Person implements Searchable {
    private String contactInfo;
    private String address;

    private List<Equipment> equipmentList = new ArrayList<>();

    public Client(int clientId, String name, String contactInfo, String address) {
        super(clientId, name);
        this.contactInfo = contactInfo;
        this.address = address;
    }

    public int getClientId() {
        return getId();
    }
    public void setClientId(int clientId) {
        setId(clientId);
    }

    public String getContactInfo() {
        return contactInfo;
    }
    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }

    public void addEquipment(Equipment equipment) {
        if (equipment != null && !equipmentList.contains(equipment)) equipmentList.add(equipment);
    }

    public void removeEquipment(int equipmentId) {
        equipmentList.removeIf(equipment -> equipment.getEquipmentId() == equipmentId);
    }

    public Equipment[] getEquipmentList() {
        return equipmentList.toArray(new Equipment[0]);
    }

    @Override
    public String getRole() {
        return "Client";
    }

    @Override
    public String getDetails() {
        return "Contact: " + contactInfo + ", Address: " + address + ", Equipment: " + equipmentList.size();
    }

    public int countEquipment() {
        return equipmentList.size();
    }

    public boolean hasEquipment() {
        return !equipmentList.isEmpty();
    }

    public boolean ownsEquipment(int equipmentId) {
        for (Equipment equipment : equipmentList) {
            if (equipment.getEquipmentId() == equipmentId) return true;
        }
        return false;
    }

    public Equipment findEquipment(int equipmentId) {
        for (Equipment equipment : equipmentList) {
            if (equipment.getEquipmentId() == equipmentId) return equipment;
        }
        return null;
    }

    public void updateContactDetails(String name, String contactInfo, String address) {
        setName(name);
        this.contactInfo = contactInfo;
        this.address = address;
    }

    @Override
    public boolean matchesSearchTerm(String term) {
        String normalizedTerm = term.toLowerCase(java.util.Locale.ROOT);
        return String.valueOf(getId()).equals(normalizedTerm)
                || nameContains(normalizedTerm)
                || (contactInfo != null && contactInfo.contains(normalizedTerm));
    }

    @Override
    public String toString() {
        return "Client{" + "clientId=" + getId() + ", " + "name=" + getName() + ", " + "contactInfo=" + contactInfo + ", " + "address=" + address + "}";
    }
}
