package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * Main menu of the application.
 * COMMAND pattern: every entry is a MenuOption (number + title + MenuAction), so adding a feature
 * means adding one line in registerOptions() instead of editing a switch and a printed list that
 * could get out of sync. The menu depends only on the PersistenceStore and UserInput interfaces.
 */
public class MaintenanceMenu {
    private final PersistenceStore dataStore;
    private final SystemState state;
    private final UserInput input;
    private final Map<Integer, MenuOption> options = new LinkedHashMap<>();
    private int exitOption;

    public MaintenanceMenu(PersistenceStore dataStore, Scanner scanner) {
        this(dataStore, new ConsoleInput(scanner));
    }

    public MaintenanceMenu(PersistenceStore dataStore, UserInput input) {
        this.dataStore = dataStore;
        this.state = dataStore.load();
        this.input = input;
        registerOptions();
    }

    public void run() {
        int option;
        do {
            printMenu();
            option = input.readInt("Choose an option: ");
            execute(option);
            dataStore.save(state);
        } while (option != exitOption);
    }

    private void registerOptions() {
        ClientActions clients = new ClientActions(state, input);
        EquipmentActions equipments = new EquipmentActions(state, input);
        TechnicianActions technicians = new TechnicianActions(state, input);
        WorkOrderActions workOrders = new WorkOrderActions(state, input);
        RecordActions records = new RecordActions(state);
        SearchActions search = new SearchActions(state, input);
        ClientAnalyticsActions analytics = new ClientAnalyticsActions(state);

        add("Register client", clients::register);
        add("Register equipment for a client", equipments::register);
        add("Register technician", technicians::register);
        add("Schedule maintenance", workOrders::scheduleMaintenance);
        add("Create work order", workOrders::createOrder);
        add("Assign technician to work order", workOrders::assignTechnician);
        add("Add task to work order", workOrders::addTask);
        add("Register part and safety regulation", workOrders::registerPartAndRegulation);
        add("Execute task", workOrders::executeTask);
        add("Close work order and generate report", workOrders::closeOrder);
        add("Record maintenance history", equipments::recordHistory);
        add("Show records", records::showAll);
        add("Remove equipment from client", clients::removeEquipment);
        add("Generate CSV Report (Excel)", records::exportCsv);
        add("Edit or delete a client", clients::editOrDelete);
        add("Show maintenance service prices", MaintenancePriceCatalog::showPrices);
        add("Search clients, equipment, technicians and work orders", search::search);
        add("Update equipment information", equipments::update);
        add("Search complete equipment maintenance history", equipments::showCompleteHistory);
        add("Consult equipment by QR code or serial number", equipments::consultByQrOrSerial);
        add("Show upcoming maintenance alerts", workOrders::showUpcomingAlerts);
        add("Update technician availability", technicians::updateAvailability);
        add("Update client contact and address", clients::updateContact);
        add("Show people (clients and technicians)", records::showPeople);
        add("Show price summary", records::showPriceSummary);
        add("Show total spent per client", analytics::showSpendingPerClient);
        add("Show averages (orders, clients)", analytics::showAverages);
        add("Show loyalty gift recipient", analytics::showLoyaltyGiftRecipient);
        add("Exit", () -> System.out.println("Goodbye!"));
        exitOption = options.size();
    }

    /** Numbers are assigned in registration order, so the printed list can never skip or repeat a number. */
    private void add(String title, MenuAction action) {
        int number = options.size() + 1;
        options.put(number, new MenuOption(number, title, action));
    }

    private void printMenu() {
        System.out.println("\n===== ELECTROMECHANICAL MAINTENANCE MANAGEMENT SYSTEM =====");
        for (MenuOption option : options.values()) {
            System.out.println(option.label());
        }
    }

    private void execute(int number) {
        MenuOption option = options.get(number);
        if (option == null) {
            System.out.println("Invalid option.");
            return;
        }
        option.run();
    }
}
