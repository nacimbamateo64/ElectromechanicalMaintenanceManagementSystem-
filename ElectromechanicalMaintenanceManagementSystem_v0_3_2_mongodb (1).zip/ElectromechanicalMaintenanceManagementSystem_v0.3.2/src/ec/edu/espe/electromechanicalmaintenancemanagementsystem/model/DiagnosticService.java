package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

/** INHERITANCE: Diagnostic service of the catalogue. POLYMORPHISM: overrides the abstract methods. */
public class DiagnosticService extends MaintenanceService {

    public DiagnosticService(int serviceId, String serviceName, String basePrice) {
        super(serviceId, serviceName, basePrice);
    }

    @Override
    public String getCategory() {
        return "Diagnostic";
    }

    @Override
    public String getDefaultPriority() {
        return "medium";
    }

    @Override
    public String getTaskType() {
        return "Inspection";
    }
}
