package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

/** INHERITANCE: Corrective service of the catalogue. POLYMORPHISM: overrides the abstract methods. */
public class CorrectiveService extends MaintenanceService {

    public CorrectiveService(int serviceId, String serviceName, String basePrice) {
        super(serviceId, serviceName, basePrice);
    }

    @Override
    public String getCategory() {
        return "Corrective";
    }

    @Override
    public String getDefaultPriority() {
        return "medium";
    }

    @Override
    public String getTaskType() {
        return "Corrective";
    }
}
