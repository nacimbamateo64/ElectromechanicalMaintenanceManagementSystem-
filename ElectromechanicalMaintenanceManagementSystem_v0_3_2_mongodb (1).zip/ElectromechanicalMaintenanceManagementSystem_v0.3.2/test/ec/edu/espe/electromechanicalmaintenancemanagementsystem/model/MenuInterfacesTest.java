package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Tests that the menu works against the PersistenceStore and UserInput interfaces,
 * using an in-memory store and scripted answers: no files and no console involved.
 */
public class MenuInterfacesTest {

    /** PersistenceStore test double that keeps everything in memory and counts the saves. */
    private static class InMemoryStore implements PersistenceStore {
        final SystemState state = new SystemState();
        int loads;
        int saves;

        @Override
        public SystemState load() {
            loads++;
            return state;
        }

        @Override
        public void save(SystemState saved) {
            assertSame(state, saved);
            saves++;
        }
    }

    private static String run(InMemoryStore store, String script) {
        return SearchableTest.capture(() -> new MaintenanceMenu(store, new Scanner(script)).run());
    }

    @Test
    public void menuLoadsOnceAndSavesAfterEveryActionIncludingExit() {
        InMemoryStore store = new InMemoryStore();
        run(store, "16\n25\n29\n");
        assertEquals(1, store.loads);
        assertEquals(3, store.saves);
    }

    @Test
    public void registeringAClientThroughTheMenuReachesThePersistenceStore() {
        InMemoryStore store = new InMemoryStore();
        run(store, "1\nAna Lopez\n0987654321\nQuito\n29\n");
        assertEquals(1, store.state.clients.size());
        assertEquals("Ana Lopez", store.state.clients.get(0).getName());
        assertEquals(1, store.state.clients.get(0).getClientId());
    }

    @Test
    public void invalidOptionIsReportedAndTheMenuKeepsRunning() {
        InMemoryStore store = new InMemoryStore();
        String output = run(store, "99\n0\n29\n");
        assertEquals(2, countOccurrences(output, "Invalid option."));
        assertTrue(output.contains("Goodbye!"));
    }

    @Test
    public void menuNumbersAreConsecutiveAndExitIsTheLastOption() {
        InMemoryStore store = new InMemoryStore();
        String output = run(store, "29\n");
        List<Integer> numbers = new ArrayList<>();
        Matcher matcher = Pattern.compile("(?m)^(\\d+)\\. ").matcher(output);
        while (matcher.find()) {
            numbers.add(Integer.parseInt(matcher.group(1)));
        }
        assertEquals(29, numbers.size());
        for (int i = 0; i < numbers.size(); i++) {
            assertEquals(i + 1, (int) numbers.get(i));
        }
        assertTrue(output.contains("29. Exit"));
        assertTrue(output.contains("28. Show loyalty gift recipient"));
    }

    @Test
    public void menuCanBeDrivenByAnyUserInputImplementation() {
        InMemoryStore store = new InMemoryStore();
        ScriptedInput input = new ScriptedInput("1", "Luis Mora", "0911111111", "Cuenca", "29");
        SearchableTest.capture(() -> new MaintenanceMenu(store, input).run());
        assertEquals("Luis Mora", store.state.clients.get(0).getName());
    }

    @Test
    public void actionsWorkWithAScriptedUserInput() {
        SystemState state = new SystemState();
        new ClientActions(state, new ScriptedInput("Renata Olalla", "0983483842", "Valle")).register();
        assertEquals(1, state.clients.size());
        assertEquals("0983483842", state.clients.get(0).getContactInfo());
    }

    @Test
    public void jsonDataStoreIsAPersistenceStore() {
        PersistenceStore store = new JsonDataStore(java.nio.file.Path.of("folder_that_does_not_exist_menu_test"));
        assertNotNull(store.load());
    }

    @Test
    public void consoleInputIsAUserInput() {
        UserInput input = new ConsoleInput(new Scanner("5\nhello\n"));
        assertEquals(5, input.readInt("n: "));
        assertEquals("hello", input.readText("t: "));
    }

    @Test(expected = IllegalArgumentException.class)
    public void menuOptionRejectsAMissingAction() {
        new MenuOption(1, "Something", null);
    }

    @Test
    public void menuOptionRunsItsActionAndBuildsItsLabel() {
        int[] calls = {0};
        MenuOption option = new MenuOption(7, "Do it", () -> calls[0]++);
        option.run();
        assertEquals(1, calls[0]);
        assertEquals("7. Do it", option.label());
    }

    private static int countOccurrences(String text, String part) {
        int count = 0;
        for (int i = text.indexOf(part); i >= 0; i = text.indexOf(part, i + part.length())) {
            count++;
        }
        return count;
    }
}
