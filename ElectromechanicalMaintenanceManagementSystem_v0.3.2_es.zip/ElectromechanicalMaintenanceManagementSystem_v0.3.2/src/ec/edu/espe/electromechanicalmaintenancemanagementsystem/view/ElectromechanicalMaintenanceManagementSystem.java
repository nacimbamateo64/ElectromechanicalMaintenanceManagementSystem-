package ec.edu.espe.electromechanicalmaintenancemanagementsystem.view;

import ec.edu.espe.electromechanicalmaintenancemanagementsystem.model.JsonDataStore;
import ec.edu.espe.electromechanicalmaintenancemanagementsystem.model.MaintenanceMenu;
import java.util.Scanner;

/** Entry point: starts the main menu with the JSON data store. The menu itself lives in MaintenanceMenu. */
public class ElectromechanicalMaintenanceManagementSystem {

    public static void main(String[] args) {
        new MaintenanceMenu(new JsonDataStore("data"), new Scanner(System.in)).run();
    }
}
