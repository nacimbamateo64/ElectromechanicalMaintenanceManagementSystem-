package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * Main menu of the application.
 * COMMAND pattern: every entry is a MenuOption (number + title + MenuAction), so adding a feature
 * means adding one line in registerOptions() instead of editing a switch and a printed list that
 * could get out of sync. The menu depends only on the PersistenceStore and UserInput interfaces.
 */
public class MaintenanceMenu {
    private final PersistenceStore dataStore;
    private final SystemState state;
    private final UserInput input;
    private final Map<Integer, MenuOption> options = new LinkedHashMap<>();
    private int exitOption;

    public MaintenanceMenu(PersistenceStore dataStore, Scanner scanner) {
        this(dataStore, new ConsoleInput(scanner));
    }

    public MaintenanceMenu(PersistenceStore dataStore, UserInput input) {
        this.dataStore = dataStore;
        this.state = dataStore.load();
        this.input = input;
        registerOptions();
    }

    public void run() {
        int option;
        do {
            printMenu();
            option = input.readInt("Elija una opción: ");
            execute(option);
            dataStore.save(state);
        } while (option != exitOption);
    }

    private void registerOptions() {
        ClientActions clients = new ClientActions(state, input);
        EquipmentActions equipments = new EquipmentActions(state, input);
        TechnicianActions technicians = new TechnicianActions(state, input);
        WorkOrderActions workOrders = new WorkOrderActions(state, input);
        RecordActions records = new RecordActions(state);
        SearchActions search = new SearchActions(state, input);
        ClientAnalyticsActions analytics = new ClientAnalyticsActions(state);

        add("Registrar cliente", clients::register);
        add("Registrar equipo para un cliente", equipments::register);
        add("Registrar técnico", technicians::register);
        add("Programar mantenimiento", workOrders::scheduleMaintenance);
        add("Crear orden de trabajo", workOrders::createOrder);
        add("Asignar técnico a la orden de trabajo", workOrders::assignTechnician);
        add("Agregar tarea a la orden de trabajo", workOrders::addTask);
        add("Registrar repuesto y norma de seguridad", workOrders::registerPartAndRegulation);
        add("Ejecutar tarea", workOrders::executeTask);
        add("Cerrar orden de trabajo y generar reporte", workOrders::closeOrder);
        add("Registrar historial de mantenimiento", equipments::recordHistory);
        add("Mostrar registros", records::showAll);
        add("Quitar equipo de un cliente", clients::removeEquipment);
        add("Generar reporte CSV (Excel)", records::exportCsv);
        add("Editar o eliminar un cliente", clients::editOrDelete);
        add("Mostrar precios de servicios de mantenimiento", MaintenancePriceCatalog::showPrices);
        add("Buscar clientes, equipos, técnicos y órdenes de trabajo", search::search);
        add("Actualizar información del equipo", equipments::update);
        add("Buscar historial completo de mantenimiento de un equipo", equipments::showCompleteHistory);
        add("Consultar equipo por código QR o número de serie", equipments::consultByQrOrSerial);
        add("Mostrar alertas de mantenimiento próximas", workOrders::showUpcomingAlerts);
        add("Actualizar disponibilidad del técnico", technicians::updateAvailability);
        add("Actualizar contacto y dirección del cliente", clients::updateContact);
        add("Mostrar personas (clientes y técnicos)", records::showPeople);
        add("Mostrar resumen de precios", records::showPriceSummary);
        add("Mostrar total gastado por cliente", analytics::showSpendingPerClient);
        add("Mostrar promedios (órdenes, clientes)", analytics::showAverages);
        add("Mostrar destinatario del obsequio de fidelidad", analytics::showLoyaltyGiftRecipient);
        add("Salir", () -> System.out.println("¡Hasta luego!"));
        exitOption = options.size();
    }

    /** Numbers are assigned in registration order, so the printed list can never skip or repeat a number. */
    private void add(String title, MenuAction action) {
        int number = options.size() + 1;
        options.put(number, new MenuOption(number, title, action));
    }

    private void printMenu() {
        System.out.println("\n===== SISTEMA DE GESTIÓN DE MANTENIMIENTO ELECTROMECÁNICO =====");
        for (MenuOption option : options.values()) {
            System.out.println(option.label());
        }
    }

    private void execute(int number) {
        MenuOption option = options.get(number);
        if (option == null) {
            System.out.println("Opción no válida.");
            return;
        }
        option.run();
    }
}
