package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

public class MaintenanceHistory implements Identifiable, java.io.Serializable {
    private int historyId;
    private String maintenanceDate;
    private String maintenanceType;
    private String description;

    public MaintenanceHistory(int historyId, String maintenanceDate, String maintenanceType, String description) {
        this.historyId = historyId;
        this.maintenanceDate = maintenanceDate;
        this.maintenanceType = maintenanceType;
        this.description = description;
    }

    @Override
    public int getId() {
        return historyId;
    }

    public int getHistoryId() {
        return historyId;
    }
    public void setHistoryId(int historyId) {
        this.historyId = historyId;
    }

    public String getMaintenanceDate() {
        return maintenanceDate;
    }
    public void setMaintenanceDate(String maintenanceDate) {
        this.maintenanceDate = maintenanceDate;
    }

    public String getMaintenanceType() {
        return maintenanceType;
    }
    public void setMaintenanceType(String maintenanceType) {
        this.maintenanceType = maintenanceType;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isOfType(String type) {
        return maintenanceType != null && maintenanceType.equalsIgnoreCase(type);
    }

    public boolean happenedOn(String date) {
        return maintenanceDate != null && maintenanceDate.equals(date);
    }

    /** Dates use the ISO format (YYYY-MM-DD), so text order is chronological order. */
    public boolean happenedAfter(MaintenanceHistory other) {
        return maintenanceDate.compareTo(other.maintenanceDate) > 0;
    }

    @Override
    public String toString() {
        return "HistorialDeMantenimiento{" + "idHistorial=" + historyId + ", " + "fechaMantenimiento=" + maintenanceDate + ", " + "tipoMantenimiento=" + maintenanceType + ", " + "descripción=" + description + "}";
    }
}
