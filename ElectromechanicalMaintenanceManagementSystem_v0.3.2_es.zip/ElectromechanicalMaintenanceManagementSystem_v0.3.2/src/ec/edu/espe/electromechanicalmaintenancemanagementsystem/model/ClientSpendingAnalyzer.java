package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Business operations over the purchases (work orders) of the clients:
 * totals per client, averages and the most loyal client.
 * A purchase is any work order that belongs to a registered client.
 */
public class ClientSpendingAnalyzer {
    private static final int MONEY_SCALE = 2;
    private static final int AVERAGE_SCALE = 2;

    private static final Comparator<ClientSpending> MOST_LOYAL_FIRST =
            Comparator.comparingInt(ClientSpending::getPurchaseCount).reversed()
                    .thenComparing(ClientSpending::getTotalSpent, Comparator.reverseOrder())
                    .thenComparingInt(spending -> spending.getClient().getClientId());

    private static final Comparator<ClientSpending> BIGGEST_SPENDER_FIRST =
            Comparator.comparing(ClientSpending::getTotalSpent, Comparator.reverseOrder())
                    .thenComparing(Comparator.comparingInt(ClientSpending::getPurchaseCount).reversed())
                    .thenComparingInt(spending -> spending.getClient().getClientId());

    private final SystemState state;

    public ClientSpendingAnalyzer(SystemState state) {
        this.state = state;
    }

    public ClientSpending summarizeSpendingOf(Client client) {
        List<WorkOrder> purchases = state.findOrdersByClient(client.getClientId());
        return new ClientSpending(client, purchases.size(), sumPrices(purchases));
    }

    public List<ClientSpending> summarizeSpendingByClient() {
        List<ClientSpending> summaries = new ArrayList<>();
        for (Client client : state.clients) {
            summaries.add(summarizeSpendingOf(client));
        }
        summaries.sort(BIGGEST_SPENDER_FIRST);
        return summaries;
    }

    public BigDecimal calculateTotalSpentBy(Client client) {
        return summarizeSpendingOf(client).getTotalSpent();
    }

    public int countPurchasesOf(Client client) {
        return summarizeSpendingOf(client).getPurchaseCount();
    }

    public BigDecimal calculateTotalRevenue() {
        return sumPrices(state.findPurchases());
    }

    public BigDecimal calculateAverageOrderPrice() {
        return average(calculateTotalRevenue(), state.findPurchases().size());
    }

    public BigDecimal calculateAverageSpentPerClient() {
        return average(calculateTotalRevenue(), state.clients.size());
    }

    public double calculateAveragePurchasesPerClient() {
        if (state.clients.isEmpty()) {
            return 0.0;
        }
        return (double) state.findPurchases().size() / state.clients.size();
    }

    public Optional<ClientSpending> findMostFrequentClient() {
        return summarizeSpendingByClient().stream()
                .filter(ClientSpending::hasPurchases)
                .min(MOST_LOYAL_FIRST);
    }

    public Optional<ClientSpending> findBiggestSpender() {
        return summarizeSpendingByClient().stream()
                .filter(ClientSpending::hasPurchases)
                .min(BIGGEST_SPENDER_FIRST);
    }

    /** The client who buys the most often receives the loyalty gift. */
    public Optional<Client> findLoyaltyGiftRecipient() {
        return findMostFrequentClient().map(ClientSpending::getClient);
    }

    public List<ClientSpending> findClientsSpendingAtLeast(BigDecimal minimumAmount) {
        List<ClientSpending> bigSpenders = new ArrayList<>();
        for (ClientSpending spending : summarizeSpendingByClient()) {
            if (spending.getTotalSpent().compareTo(minimumAmount) >= 0) {
                bigSpenders.add(spending);
            }
        }
        return bigSpenders;
    }

    private static BigDecimal sumPrices(List<WorkOrder> orders) {
        BigDecimal total = BigDecimal.ZERO;
        for (WorkOrder order : orders) {
            total = total.add(order.calculatePrice());
        }
        return total.setScale(MONEY_SCALE, RoundingMode.HALF_UP);
    }

    private static BigDecimal average(BigDecimal total, int count) {
        if (count == 0) {
            return BigDecimal.ZERO.setScale(AVERAGE_SCALE);
        }
        return total.divide(BigDecimal.valueOf(count), AVERAGE_SCALE, RoundingMode.HALF_UP);
    }
}
