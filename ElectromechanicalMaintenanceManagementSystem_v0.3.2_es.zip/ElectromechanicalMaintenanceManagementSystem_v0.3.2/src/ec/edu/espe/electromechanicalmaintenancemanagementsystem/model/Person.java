package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

/**
 * ABSTRACTION + INHERITANCE: common base class for the people in the system.
 * Client and Technician extend this class and inherit id and name.
 * POLYMORPHISM: getRole() and getDetails() are abstract and every subclass
 * gives its own implementation; describe() works for any Person.
 */
public abstract class Person implements Identifiable, java.io.Serializable {
    private int id;
    private String name;

    protected Person(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public int getId() {
        return id;
    }

    protected void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /** Role of the person in the system, for example "Client" or "Technician". */
    public abstract String getRole();

    /** Specific information of each subclass. */
    public abstract String getDetails();

    /** Template method: same format for every person, details resolved polymorphically. */
    public final String describe() {
        return getRole() + " #" + id + " - " + name + " | " + getDetails();
    }

    public boolean hasId(int candidateId) {
        return id == candidateId;
    }

    public boolean nameContains(String term) {
        return name != null && name.toLowerCase(java.util.Locale.ROOT)
                .contains(term.toLowerCase(java.util.Locale.ROOT));
    }
}
