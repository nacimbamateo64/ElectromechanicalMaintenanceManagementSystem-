package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

/**
 * POLYMORPHISM: contract for every record that can be found by a free-text term.
 * Each class decides which of its fields take part in the match (ID, name, serial number...).
 * Implementations must be case-insensitive and must not modify the record.
 */
public interface Searchable {
    boolean matchesSearchTerm(String term);

    /** Same search for any kind of record: keeps the items that match the term, in their original order. */
    static <T extends Searchable> List<T> filter(Collection<? extends T> items, String term) {
        List<T> matches = new ArrayList<>();
        if (items == null || term == null) {
            return matches;
        }
        for (T item : items) {
            if (item.matchesSearchTerm(term)) {
                matches.add(item);
            }
        }
        return matches;
    }

    /** Null-safe, case-insensitive "contains" shared by the implementations. */
    static boolean containsIgnoreCase(String text, String term) {
        return text != null && term != null
                && text.toLowerCase(Locale.ROOT).contains(term.toLowerCase(Locale.ROOT));
    }
}
