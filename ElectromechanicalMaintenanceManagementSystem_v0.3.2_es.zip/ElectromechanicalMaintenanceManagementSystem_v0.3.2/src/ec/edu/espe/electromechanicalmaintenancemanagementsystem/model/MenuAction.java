package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

/** COMMAND: one thing the user can do from the main menu. Lets the menu be a table instead of a switch. */
@FunctionalInterface
public interface MenuAction {
    void execute();
}
