package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

public class Report implements Identifiable, java.io.Serializable {
    private int reportId;
    private String reportType;
    private String generatedDate;
    private String dataContent;

    public Report(int reportId, String reportType, String generatedDate, String dataContent) {
        this.reportId = reportId;
        this.reportType = reportType;
        this.generatedDate = generatedDate;
        this.dataContent = dataContent;
    }

    @Override
    public int getId() {
        return reportId;
    }

    public int getReportId() {
        return reportId;
    }
    public void setReportId(int reportId) {
        this.reportId = reportId;
    }

    public String getReportType() {
        return reportType;
    }
    public void setReportType(String reportType) {
        this.reportType = reportType;
    }

    public String getGeneratedDate() {
        return generatedDate;
    }
    public void setGeneratedDate(String generatedDate) {
        this.generatedDate = generatedDate;
    }

    public String getDataContent() {
        return dataContent;
    }
    public void setDataContent(String dataContent) {
        this.dataContent = dataContent;
    }

    public boolean isOfType(String type) {
        return reportType != null && reportType.equalsIgnoreCase(type);
    }

    public boolean wasGeneratedOn(String date) {
        return generatedDate != null && generatedDate.equals(date);
    }

    public boolean contentMentions(String term) {
        return dataContent != null && dataContent.toLowerCase(java.util.Locale.ROOT)
                .contains(term.toLowerCase(java.util.Locale.ROOT));
    }

    @Override
    public String toString() {
        return "Reporte{" + "idReporte=" + reportId + ", " + "tipoReporte=" + reportType + ", " + "fechaGeneración=" + generatedDate + ", " + "contenido=" + dataContent + "}";
    }
}
