package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

/**
 * ABSTRACTION: contract for exporting the system state to a report file or folder.
 * CsvDataExporter writes the CSV files that Excel opens; other formats (PDF, XLSX, JSON)
 * can implement this interface and be plugged into RecordActions.
 */
public interface DataExporter {
    /** Exports the state; {@code target} names the main output file (its folder is used for the rest). */
    void export(String target, SystemState state);
}
