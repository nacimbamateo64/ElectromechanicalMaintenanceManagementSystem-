package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import static ec.edu.espe.electromechanicalmaintenancemanagementsystem.model.ConsoleOutput.show;

import java.time.LocalDate;
import java.util.Arrays;


public class WorkOrderActions {
    private static final String CLOSED = "Closed";

    private final SystemState state;
    private final UserInput input;

    public WorkOrderActions(SystemState state, UserInput input) {
        this.state = state;
        this.input = input;
    }

    public void scheduleMaintenance() {
        Equipment equipment = chooseEquipment();
        if (equipment == null) {
            return;
        }
        String frequency = input.readText("Frecuencia: ");
        String date = input.readDate("Fecha programada (AAAA-MM-DD, hoy o futura dentro de este año): ");
        boolean preventive = input.readBoolean("Mantenimiento preventivo (sí/no): ");
        MaintenanceSchedule schedule = new MaintenanceSchedule(state.nextScheduleId(), frequency, date, preventive);
        state.schedules.add(schedule);
        equipment.assignSchedule(schedule);
        System.out.println(schedule);
    }

    /** Client -> that client's equipment -> service catalogue with prices -> work order. */
    public void createOrder() {
        Client client = chooseClient();
        if (client == null) {
            return;
        }
        Equipment equipment = chooseClientEquipment(client);
        if (equipment == null) {
            return;
        }
        System.out.println("\nServicios disponibles para " + client.getName() + ":");
        int serviceIndex = MaintenancePriceCatalog.chooseService(input);
        // Polymorphism: the concrete subclass decides category, suggested priority and description.
        MaintenanceService service = MaintenancePriceCatalog.getService(serviceIndex);
        System.out.println("Seleccionado: " + service.describe());
        WorkOrder order = equipment.requestMaintenanceOrder();
        order.setWorkOrderId(state.nextOrderId());
        order.setClientId(client.getClientId());
        order.setEquipmentId(equipment.getEquipmentId());
        order.applyService(service);
        order.setDescription("ID del equipo: " + equipment.getEquipmentId()
                + " | Servicio: " + service.getServiceName()
                + " | Detalles: " + input.readText("Detalles adicionales del trabajo: "));
        if (service.requiresImmediateAttention()) {
            order.setPriority(service.getDefaultPriority());
            System.out.println("Servicio de emergencia: prioridad establecida en " + service.getDefaultPriority() + ".");
        } else {
            order.setPriority(input.readChoice("Prioridad (low/medium/high) [sugerida: "
                    + service.getDefaultPriority() + "]: ", "low", "medium", "high"));
        }
        state.orders.add(order);
        equipment.updateStatus("Maintenance required");
        System.out.printf("Precio estimado del servicio: $%.2f USD%n", order.getPrice());
        System.out.println(order);
    }

    public void assignTechnician() {
        if (state.orders.isEmpty() || state.technicians.isEmpty()) {
            System.out.println("Primero registre un técnico y una orden de trabajo.");
            return;
        }
        show(state.orders);
        WorkOrder order = state.findOrder(input.readInt("ID de la orden de trabajo: "));
        show(state.technicians);
        Technician technician = state.findTechnician(input.readInt("ID del técnico: "));
        if (order == null || technician == null || CLOSED.equals(order.getStatus())
                || order.getTechnician() != null || !technician.getAvailabilityStatus()) {
            System.out.println("Selección no válida o técnico no disponible.");
            return;
        }
        technician.acceptWorkOrder(order);
        order.setStatus("In progress");
        System.out.println("Técnico asignado: " + technician.getName());
    }

    public void addTask() {
        if (state.orders.isEmpty()) {
            System.out.println("Primero cree una orden de trabajo.");
            return;
        }
        show(state.orders);
        WorkOrder order = state.findOrder(input.readInt("ID de la orden de trabajo: "));
        if (order == null || CLOSED.equals(order.getStatus())) {
            System.out.println("Orden de trabajo no encontrada o cerrada.");
            return;
        }
        MaintenanceTask task = order.createTask();
        task.setTaskDescription(input.readText("Descripción de la tarea: "));
        MaintenanceService service = order.findService();
        String typePrompt = service == null ? "Tipo de tarea: "
                : "Tipo de tarea [sugerido para servicio " + service.getCategory() + " : " + service.getTaskType() + "]: ";
        task.setTaskType(input.readText(typePrompt));
        task.setEstimatedDuration(input.readNonNegativeFloat("Duración estimada en horas (0 o mayor): "));
        System.out.println(task);
    }

    public void registerPartAndRegulation() {
        if (state.orders.isEmpty()) {
            System.out.println("Primero cree una orden de trabajo y una tarea.");
            return;
        }
        WorkOrder order = chooseOpenOrderWithTasks("No se encontró ninguna orden abierta con tareas.");
        if (order == null) {
            return;
        }
        MaintenanceTask task = chooseTask(order);
        if (task == null || task.getIsCompleted()) {
            System.out.println("Tarea no encontrada o ya completada.");
            return;
        }
        if (input.readBoolean("Agregar un repuesto (sí/no): ")) {
            registerPart(task);
        }
        registerRegulation(task);
    }

    public void executeTask() {
        WorkOrder order = chooseOpenOrderWithTasks("No se encontró ninguna orden abierta con tareas.");
        if (order == null) {
            return;
        }
        MaintenanceTask task = chooseTask(order);
        if (task == null || task.getIsCompleted() || task.getRegulations().isEmpty()) {
            System.out.println("Tarea no encontrada, ya completada o sin verificación de seguridad.");
            return;
        }
        task.executeTask();
        System.out.println("Tarea completada: " + task.getIsCompleted());
    }

    public void closeOrder() {
        WorkOrder order = chooseOpenOrderWithTasks("No se encontró ninguna orden de trabajo abierta con tareas.");
        if (order == null) {
            return;
        }
        order.closeOrder();
        if (!CLOSED.equals(order.getStatus())) {
            System.out.println("Complete todas las tareas antes de cerrar la orden.");
            return;
        }
        recordHistoryOf(order);
        Report report = order.createReport();
        report.setReportId(state.nextReportId());
        state.reports.add(report);
        Alert alert = order.createAlert();
        alert.setMessage("Orden de trabajo completada");
        alert.setIsResolved(true);
        state.alerts.add(alert);
        System.out.println(report);
        System.out.println(alert);
    }

    public void showUpcomingAlerts() {
        LocalDate today = LocalDate.now();
        boolean any = false;
        for (MaintenanceSchedule schedule : state.schedules) {
            any |= printIfDue(schedule, today);
        }
        for (Alert alert : state.alerts) {
            if (!alert.getIsResolved()) {
                any = true;
                System.out.println("ALERTA PENDIENTE: " + alert);
            }
        }
        if (!any) {
            System.out.println("No hay mantenimientos próximos ni vencidos en los próximos 30 días.");
        }
    }

    private Client chooseClient() {
        if (state.clients.isEmpty()) {
            System.out.println("Primero registre un cliente.");
            return null;
        }
        show(state.clients);
        Client client = state.findClient(input.readInt("ID del cliente: "));
        if (client == null) {
            System.out.println("Cliente no encontrado.");
        }
        return client;
    }

    private Equipment chooseClientEquipment(Client client) {
        Equipment[] owned = client.getEquipmentList();
        if (owned.length == 0) {
            System.out.println("Este cliente no tiene equipos. Primero registre un equipo (opción 2).");
            return null;
        }
        System.out.println("Equipos de " + client.getName() + ":");
        show(Arrays.asList(owned));
        int equipmentId = input.readInt("ID del equipo: ");
        for (Equipment equipment : owned) {
            if (equipment.getEquipmentId() == equipmentId) {
                return equipment;
            }
        }
        System.out.println("Ese equipo no pertenece al cliente seleccionado.");
        return null;
    }

    private Equipment chooseEquipment() {
        if (state.equipments.isEmpty()) {
            System.out.println("Primero registre un equipo.");
            return null;
        }
        show(state.equipments);
        Equipment equipment = state.findEquipment(input.readInt("ID del equipo: "));
        if (equipment == null) {
            System.out.println("Equipo no encontrado.");
        }
        return equipment;
    }

    
    private WorkOrder chooseOpenOrderWithTasks(String notFoundMessage) {
        show(state.orders);
        WorkOrder order = state.findOrder(input.readInt("ID de la orden de trabajo: "));
        if (order == null || CLOSED.equals(order.getStatus()) || order.getTasks().isEmpty()) {
            System.out.println(notFoundMessage);
            return null;
        }
        return order;
    }

    private MaintenanceTask chooseTask(WorkOrder order) {
        show(order.getTasks());
        return order.findTask(input.readInt("ID de la tarea: "));
    }

    private void registerPart(MaintenanceTask task) {
        String name = input.readText("Nombre del repuesto: ");
        int quantity = input.readNonNegativeInt("Cantidad en inventario (0 o mayor): ");
        float cost = input.readNonNegativeFloat("Costo unitario (0 o mayor): ");
        String supplier = input.readText("Proveedor: ");
        Part part = new Part(state.nextPartId(), name, quantity, cost, supplier);
        state.parts.add(part);
        task.recordPart(part);
        System.out.println(part);
    }

    private void registerRegulation(MaintenanceTask task) {
        String title = input.readText("Título de la norma de seguridad: ");
        String description = input.readText("Descripción de seguridad: ");
        String risk = input.readChoice("Nivel de riesgo (low/medium/high/critical): ", "low", "medium", "high", "critical");
        SafetyRegulation regulation = new SafetyRegulation(state.nextRegulationId(), title, description, risk);
        state.regulations.add(regulation);
        task.verifySafety(regulation);
        System.out.println(regulation);
    }

    private void recordHistoryOf(WorkOrder order) {
        Equipment maintained = state.findEquipment(order.extractEquipmentId());
        if (maintained == null) {
            return;
        }
        MaintenanceHistory history = new MaintenanceHistory(state.nextHistoryId(),
                LocalDate.now().toString(), "Correctivo/Orden de trabajo completada", order.buildMaintenanceDetails());
        state.histories.add(history);
        maintained.attachHistory(history);
    }

    private boolean printIfDue(MaintenanceSchedule schedule, LocalDate today) {
        try {
            LocalDate due = LocalDate.parse(schedule.getScheduleDate());
            if (due.isBefore(today)) {
                System.out.println("VENCIDO: " + schedule);
                return true;
            }
            if (!due.isAfter(today.plusDays(30))) {
                System.out.println("PRÓXIMO: " + schedule);
                return true;
            }
        } catch (RuntimeException ignored) {
          
        }
        return false;
    }
}
