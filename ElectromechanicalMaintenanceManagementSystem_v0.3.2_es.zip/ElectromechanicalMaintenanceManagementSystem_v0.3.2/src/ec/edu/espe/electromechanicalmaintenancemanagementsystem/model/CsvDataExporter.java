package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

/** DataExporter that writes the CSV files (UTF-8 with BOM, readable in Excel). */
public class CsvDataExporter implements DataExporter {
    @Override
    public void export(String target, SystemState state) {
        CsvExporter.export(target, state);
    }
}
