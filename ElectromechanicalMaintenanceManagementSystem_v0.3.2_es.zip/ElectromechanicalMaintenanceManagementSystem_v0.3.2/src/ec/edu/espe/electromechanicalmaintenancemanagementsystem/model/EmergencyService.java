package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

/** INHERITANCE: Emergency service of the catalogue. POLYMORPHISM: overrides the abstract methods. */
public class EmergencyService extends MaintenanceService {

    public EmergencyService(int serviceId, String serviceName, String basePrice) {
        super(serviceId, serviceName, basePrice);
    }

    @Override
    public String getCategory() {
        return "Emergencia";
    }

    @Override
    public String getDefaultPriority() {
        return "high";
    }

    @Override
    public String getTaskType() {
        return "Correctivo";
    }

    @Override
    public boolean requiresImmediateAttention() {
        return true;
    }

    @Override
    public String describe() {
        return super.describe() + " - ATENCIÓN INMEDIATA";
    }
}
