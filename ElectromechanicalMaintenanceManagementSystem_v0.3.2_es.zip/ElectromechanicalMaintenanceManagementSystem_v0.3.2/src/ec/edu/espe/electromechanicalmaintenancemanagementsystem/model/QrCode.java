package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

public class QrCode implements Identifiable, java.io.Serializable {
    private int qrId;
    private String codeData;
    private String generateUrl;

    public QrCode(int qrId, String codeData, String generateUrl) {
        this.qrId = qrId;
        this.codeData = codeData;
        this.generateUrl = generateUrl;
    }

    @Override
    public int getId() {
        return qrId;
    }

    public int getQrId() {
        return qrId;
    }
    public void setQrId(int qrId) {
        this.qrId = qrId;
    }

    public String getCodeData() {
        return codeData;
    }
    public void setCodeData(String codeData) {
        this.codeData = codeData;
    }

    public String getGenerateUrl() {
        return generateUrl;
    }
    public void setGenerateUrl(String generateUrl) {
        this.generateUrl = generateUrl;
    }

    public boolean hasUrl() {
        return generateUrl != null && !generateUrl.isBlank();
    }

    public boolean matchesCodeData(String candidateCodeData) {
        return codeData != null && codeData.equalsIgnoreCase(candidateCodeData);
    }

    @Override
    public String toString() {
        return "CódigoQR{" + "idQR=" + qrId + ", " + "datosCódigo=" + codeData + ", " + "urlGenerada=" + generateUrl + "}";
    }
}
