package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import static ec.edu.espe.electromechanicalmaintenancemanagementsystem.model.ConsoleOutput.show;


/** Console actions that show or export all records. */
public class RecordActions {
    private static final String EXPORT_FILE = "maintenance_report.csv";

    private final SystemState state;
    private final DataExporter exporter;

    public RecordActions(SystemState state) {
        this(state, new CsvDataExporter());
    }

    public RecordActions(SystemState state, DataExporter exporter) {
        this.state = state;
        this.exporter = exporter;
    }

    public void showAll() {
        System.out.println("\nCLIENTES");
        show(state.clients);
        System.out.println("\nEQUIPOS");
        show(state.equipments);
        System.out.println("\nCÓDIGOS QR");
        show(state.qrCodes);
        System.out.println("\nTÉCNICOS");
        show(state.technicians);
        System.out.println("\nPROGRAMACIONES DE MANTENIMIENTO");
        show(state.schedules);
        System.out.println("\nÓRDENES DE TRABAJO");
        show(state.orders);
        for (WorkOrder order : state.orders) {
            System.out.println("Tareas de la orden de trabajo " + order.getWorkOrderId());
            show(order.getTasks());
        }
        System.out.println("\nREPUESTOS");
        show(state.parts);
        System.out.println("\nNORMAS DE SEGURIDAD");
        show(state.regulations);
        System.out.println("\nHISTORIALES DE MANTENIMIENTO");
        show(state.histories);
        System.out.println("\nALERTAS");
        show(state.alerts);
        System.out.println("\nREPORTES");
        show(state.reports);
    }

    /** POLYMORPHISM: clients and technicians handled through their common parent Person. */
    public void showPeople() {
        java.util.List<Person> people = new java.util.ArrayList<>();
        people.addAll(state.clients);
        people.addAll(state.technicians);
        System.out.println("\nPERSONAS REGISTRADAS (" + people.size() + ")");
        if (people.isEmpty()) {
            System.out.println("Sin registros.");
        }
        for (Person person : people) {
            System.out.println(person.describe());
        }
    }

    /** POLYMORPHISM: services, work orders and parts priced through the Priceable interface. */
    public void showPriceSummary() {
        java.math.BigDecimal ordersTotal = java.math.BigDecimal.ZERO;
        java.math.BigDecimal partsTotal = java.math.BigDecimal.ZERO;
        System.out.println("\nRESUMEN DE PRECIOS (USD)");
        for (Priceable order : state.orders) {
            ordersTotal = ordersTotal.add(order.calculatePrice());
        }
        for (Priceable part : state.parts) {
            partsTotal = partsTotal.add(part.calculatePrice());
        }
        java.util.Map<String, Integer> byCategory = new java.util.LinkedHashMap<>();
        for (MaintenanceService service : MaintenancePriceCatalog.getServices()) {
            byCategory.merge(service.getCategory(), 1, Integer::sum);
        }
        System.out.println("Servicios del catálogo por categoría: " + byCategory);
        System.out.println("Órdenes de trabajo (" + state.orders.size() + "): $" + ordersTotal.setScale(2).toPlainString());
        System.out.println("Repuestos en inventario (" + state.parts.size() + "): $" + partsTotal.setScale(2).toPlainString());
    }

    public void exportCsv() {
        exporter.export(EXPORT_FILE, state);
    }
}
