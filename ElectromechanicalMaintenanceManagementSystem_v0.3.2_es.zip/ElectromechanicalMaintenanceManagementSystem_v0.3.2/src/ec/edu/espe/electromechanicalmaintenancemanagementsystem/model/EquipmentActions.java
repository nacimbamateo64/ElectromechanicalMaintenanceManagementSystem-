package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import static ec.edu.espe.electromechanicalmaintenancemanagementsystem.model.ConsoleOutput.show;

import java.time.LocalDate;
import java.util.Locale;


public class EquipmentActions {
    private final SystemState state;
    private final UserInput input;

    public EquipmentActions(SystemState state, UserInput input) {
        this.state = state;
        this.input = input;
    }

    public void register() {
        if (state.clients.isEmpty()) {
            System.out.println("Primero registre un cliente.");
            return;
        }
        show(state.clients);
        Client client = state.findClient(input.readInt("ID del cliente: "));
        if (client == null) {
            System.out.println("Cliente no encontrado.");
            return;
        }
        String name = input.readName("Nombre del equipo: ");
        String serial = input.readText("Número de serie: ");
        String location = input.readText("Ubicación: ");
        Equipment equipment = new Equipment(state.nextEquipmentId(), name, serial, location, "Available");
        state.equipments.add(equipment);
        client.addEquipment(equipment);
        QrCode qr = equipment.createQrCode();
        state.qrCodes.add(qr);
        System.out.println(equipment);
        System.out.println(qr);
    }

    public void recordHistory() {
        show(state.equipments);
        Equipment equipment = state.findEquipment(input.readInt("ID del equipo: "));
        if (equipment == null) {
            System.out.println("Equipo no encontrado.");
            return;
        }
        String type = input.readText("Tipo de mantenimiento: ");
        String description = input.readText("Descripción: ");
        MaintenanceHistory history = new MaintenanceHistory(state.nextHistoryId(),
                LocalDate.now().toString(), type, description);
        state.histories.add(history);
        equipment.attachHistory(history);
        System.out.println(history);
    }

    public void update() {
        show(state.equipments);
        Equipment equipment = state.findEquipment(input.readPositiveInt("ID del equipo: "));
        if (equipment == null) {
            System.out.println("Equipo no encontrado.");
            return;
        }
        equipment.setName(input.readName("Nuevo nombre del equipo: "));
        equipment.setSerialNumber(input.readText("Nuevo número de serie: "));
        equipment.setLocation(input.readText("Nueva ubicación: "));
        equipment.setStatus(input.readText("Nuevo estado: "));
        System.out.println("Equipo actualizado: " + equipment);
    }

    public void showCompleteHistory() {
        show(state.equipments);
        Equipment equipment = state.findEquipment(input.readPositiveInt("ID del equipo: "));
        if (equipment == null) {
            System.out.println("Equipo no encontrado.");
            return;
        }
        System.out.println("Historial registrado directamente para el equipo:");
        show(equipment.getMaintenanceHistories());
        System.out.println("Mantenimientos programados:");
        show(equipment.getMaintenanceSchedules());
        System.out.println("Órdenes de trabajo:");
        for (WorkOrder order : state.orders) {
            if (mentionsEquipment(order, equipment)) {
                System.out.println(order);
            }
        }
    }

    public void consultByQrOrSerial() {
        String code = input.readText("Escanee/pegue el contenido del QR, el ID del QR o el número de serie del equipo: ");
        Equipment found = findByQrOrSerial(code);
        if (found == null) {
            System.out.println("Ningún equipo coincide con ese contenido de QR o número de serie.");
            return;
        }
        System.out.println("Información del equipo: " + found);
        for (Client client : state.clients) {
            for (Equipment owned : client.getEquipmentList()) {
                if (owned.getEquipmentId() == found.getEquipmentId()) {
                    System.out.println("Cliente: " + client);
                }
            }
        }
        System.out.println("Contenido del QR: " + found.createQrCode().getGenerateUrl());
    }

    private boolean mentionsEquipment(WorkOrder order, Equipment equipment) {
        String description = order.getDescription().toLowerCase(Locale.ROOT);
        return description.contains(equipment.getName().toLowerCase(Locale.ROOT))
                || description.contains("id del equipo: " + equipment.getEquipmentId())
                || description.contains("equipment id: " + equipment.getEquipmentId());
    }

    private Equipment findByQrOrSerial(String code) {
        for (Equipment equipment : state.equipments) {
            QrCode qr = equipment.createQrCode();
            if (code.equalsIgnoreCase(String.valueOf(qr.getQrId()))
                    || code.equalsIgnoreCase(qr.getCodeData())
                    || code.equalsIgnoreCase(qr.getGenerateUrl())
                    || code.equalsIgnoreCase(equipment.getSerialNumber())) {
                return equipment;
            }
        }
        return null;
    }
}
