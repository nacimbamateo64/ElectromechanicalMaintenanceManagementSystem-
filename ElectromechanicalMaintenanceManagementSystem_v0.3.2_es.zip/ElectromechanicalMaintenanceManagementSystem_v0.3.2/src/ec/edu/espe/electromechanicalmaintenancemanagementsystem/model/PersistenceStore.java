package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

/**
 * ABSTRACTION: contract for loading and saving the whole system state.
 * JsonDataStore implements it with one JSON file per record type. Another implementation
 * (for example one backed by the MongoDB collections in the mongodb/ folder, or an
 * in-memory store for tests) can replace it without changing the menu.
 */
public interface PersistenceStore {
    /** Reads every record and rebuilds the relations between them. Never returns null. */
    SystemState load();

    /** Writes every record of the given state. */
    void save(SystemState state);
}
