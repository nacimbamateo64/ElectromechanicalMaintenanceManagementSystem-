package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import static ec.edu.espe.electromechanicalmaintenancemanagementsystem.model.ConsoleOutput.show;

import java.util.Arrays;


public class ClientActions {
    private final SystemState state;
    private final UserInput input;

    public ClientActions(SystemState state, UserInput input) {
        this.state = state;
        this.input = input;
    }

    public void register() {
        String name = input.readName("Nombre del cliente (solo letras): ");
        String contact = input.readPhone("Información de contacto (10 dígitos que empiezan con 0): ");
        String address = input.readText("Dirección: ");
        Client client = new Client(state.nextClientId(), name, contact, address);
        state.clients.add(client);
        System.out.println("Cliente guardado en data/clients.json.");
        System.out.println(client);
    }

    public void removeEquipment() {
        show(state.clients);
        Client client = state.findClient(input.readInt("ID del cliente: "));
        if (client == null) {
            System.out.println("Cliente no encontrado.");
            return;
        }
        show(Arrays.asList(client.getEquipmentList()));
        int equipmentId = input.readInt("ID del equipo a quitar del cliente: ");
        if (!client.ownsEquipment(equipmentId)) {
            System.out.println("Ese equipo no está asignado al cliente seleccionado.");
            return;
        }
        client.removeEquipment(equipmentId);
        System.out.println("Asociación del equipo eliminada de este cliente. El registro del equipo permanece en el sistema.");
        System.out.println("Lista actualizada de equipos del cliente:");
        show(Arrays.asList(client.getEquipmentList()));
    }

    public void editOrDelete() {
        if (state.clients.isEmpty()) {
            System.out.println("No hay clientes registrados.");
            return;
        }
        System.out.println("1. Corregir el nombre de un cliente");
        System.out.println("2. Eliminar un cliente por completo");
        int action = input.readIntInRange("Elija: ", 1, 2);
        show(state.clients);
        Client selected = state.findClient(input.readPositiveInt("ID del cliente: "));
        if (selected == null) {
            System.out.println("Cliente no encontrado.");
            return;
        }
        if (action == 1) {
            selected.setName(input.readName("Nombre corregido del cliente: "));
            System.out.println("Nombre del cliente actualizado y guardado.");
        } else {
            deleteClient(selected);
        }
    }

    public void updateContact() {
        show(state.clients);
        Client client = state.findClient(input.readPositiveInt("ID del cliente: "));
        if (client == null) {
            System.out.println("Cliente no encontrado.");
            return;
        }
        client.setName(input.readName("Nombre del cliente: "));
        client.setContactInfo(input.readPhone("Teléfono de contacto: "));
        client.setAddress(input.readText("Dirección: "));
        System.out.println("Información del cliente actualizada.");
    }

    private void deleteClient(Client client) {
        if (input.readBoolean("Confirmar eliminación permanente (sí/no): ")) {
            state.clients.remove(client);
            System.out.println("Cliente eliminado de data/clients.json.");
            System.out.println("Nota: los registros de equipos del cliente no se eliminan automáticamente.");
        } else {
            System.out.println("Eliminación cancelada.");
        }
    }
}
