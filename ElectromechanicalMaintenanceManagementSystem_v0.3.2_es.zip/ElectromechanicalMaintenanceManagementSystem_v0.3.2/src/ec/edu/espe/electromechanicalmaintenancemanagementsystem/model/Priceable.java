package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * ABSTRACTION: contract for everything that has a monetary value in USD.
 * Prices use BigDecimal (2 decimals) so they are exact, matching
 * MongoDB Decimal128 values.
 * POLYMORPHISM: MaintenanceService, Part and WorkOrder each implement
 * calculatePrice() in their own way.
 */
public interface Priceable {
    BigDecimal calculatePrice();

    default String getFormattedPrice() {
        return "$" + calculatePrice().setScale(2, RoundingMode.HALF_UP).toPlainString() + " USD";
    }
}
