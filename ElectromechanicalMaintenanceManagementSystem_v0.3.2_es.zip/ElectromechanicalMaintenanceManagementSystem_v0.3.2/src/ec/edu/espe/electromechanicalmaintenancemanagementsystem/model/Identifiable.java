package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.Collection;
import java.util.Optional;

/**
 * ABSTRACTION: contract for every entity that has a unique numeric identifier.
 * Implemented by every record of the system (Person -> Client/Technician, Equipment, WorkOrder,
 * MaintenanceTask, Part, ...), so lookups and ID generation are written once for all of them.
 */
public interface Identifiable {
    int getId();

    /** Finds the item with the given ID in any collection of identifiable records. */
    static <T extends Identifiable> Optional<T> findById(Collection<? extends T> items, int id) {
        for (T item : items) {
            if (item.getId() == id) {
                return Optional.of(item);
            }
        }
        return Optional.empty();
    }

    /**
     * Next free ID: highest existing ID + 1 (1 for an empty collection).
     * Unlike "size + 1" it never repeats an ID when there are gaps after deletions.
     */
    static int nextId(Collection<? extends Identifiable> items) {
        int max = 0;
        for (Identifiable item : items) {
            max = Math.max(max, item.getId());
        }
        return max + 1;
    }
}
