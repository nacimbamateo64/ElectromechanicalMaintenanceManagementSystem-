package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import static ec.edu.espe.electromechanicalmaintenancemanagementsystem.model.ConsoleOutput.show;



public class TechnicianActions {
    private final SystemState state;
    private final UserInput input;

    public TechnicianActions(SystemState state, UserInput input) {
        this.state = state;
        this.input = input;
    }

    public void register() {
        String name = input.readName("Nombre del técnico: ");
        String expertise = input.readText("Especialidad: ");
        Technician technician = new Technician(state.nextTechnicianId(), name, expertise, true);
        state.technicians.add(technician);
        System.out.println(technician);
    }

    public void updateAvailability() {
        show(state.technicians);
        Technician technician = state.findTechnician(input.readPositiveInt("ID del técnico: "));
        if (technician == null) {
            System.out.println("Técnico no encontrado.");
            return;
        }
        technician.setAvailabilityStatus(input.readBoolean("Técnico disponible (sí/no): "));
        System.out.println("Disponibilidad del técnico actualizada: " + technician);
    }
}
