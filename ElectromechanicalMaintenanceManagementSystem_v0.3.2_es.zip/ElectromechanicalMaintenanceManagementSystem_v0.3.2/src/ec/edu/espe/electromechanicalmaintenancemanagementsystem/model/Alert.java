package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

public class Alert implements Identifiable, java.io.Serializable {
    private int alertId;
    private String message;
    private String severity;
    private boolean isResolved;

    public Alert(int alertId, String message, String severity, boolean isResolved) {
        this.alertId = alertId;
        this.message = message;
        this.severity = severity;
        this.isResolved = isResolved;
    }

    @Override
    public int getId() {
        return alertId;
    }

    public int getAlertId() {
        return alertId;
    }
    public void setAlertId(int alertId) {
        this.alertId = alertId;
    }

    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }

    public String getSeverity() {
        return severity;
    }
    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public boolean getIsResolved() {
        return isResolved;
    }
    public void setIsResolved(boolean isResolved) {
        this.isResolved = isResolved;
    }

    public boolean isPending() {
        return !isResolved;
    }

    public void resolve() {
        isResolved = true;
    }

    public boolean isHighSeverity() {
        return "High".equalsIgnoreCase(severity);
    }

    @Override
    public String toString() {
        return "Alerta{" + "idAlerta=" + alertId + ", " + "mensaje=" + message + ", " + "severidad=" + severity + ", " + "resuelta=" + isResolved + "}";
    }
}
