package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

/** INHERITANCE: Preventive service of the catalogue. POLYMORPHISM: overrides the abstract methods. */
public class PreventiveService extends MaintenanceService {

    public PreventiveService(int serviceId, String serviceName, String basePrice) {
        super(serviceId, serviceName, basePrice);
    }

    @Override
    public String getCategory() {
        return "Preventivo";
    }

    @Override
    public String getDefaultPriority() {
        return "low";
    }

    @Override
    public String getTaskType() {
        return "Preventivo";
    }
}
