package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.List;
import java.util.Locale;

/**
 * Console action for the unified search (menu option 17).
 * POLYMORPHISM: clients, equipment, technicians and work orders are all searched through
 * the Searchable interface, so no matching logic is repeated here.
 */
public class SearchActions {
    private final SystemState state;
    private final UserInput input;

    public SearchActions(SystemState state, UserInput input) {
        this.state = state;
        this.input = input;
    }

    public void search() {
        System.out.println("1. Buscar cliente por ID o nombre");
        System.out.println("2. Buscar equipo por ID, nombre o número de serie");
        System.out.println("3. Buscar técnico por ID, nombre o especialidad");
        System.out.println("4. Buscar orden de trabajo por ID, descripción, servicio o estado");
        int searchType = input.readIntInRange("Elija: ", 1, 4);
        String term = input.readText("Término de búsqueda: ").toLowerCase(Locale.ROOT);
        switch (searchType) {
            case 1: showMatches(Searchable.filter(state.clients, term)); break;
            case 2: showEquipmentMatches(Searchable.filter(state.equipments, term)); break;
            case 3: showMatches(Searchable.filter(state.technicians, term)); break;
            default: showMatches(Searchable.filter(state.orders, term));
        }
    }

    private void showMatches(List<? extends Searchable> matches) {
        if (matches.isEmpty()) {
            System.out.println("No se encontraron coincidencias.");
            return;
        }
        for (Searchable match : matches) {
            System.out.println(match);
        }
    }

    private void showEquipmentMatches(List<Equipment> matches) {
        if (matches.isEmpty()) {
            System.out.println("No se encontraron coincidencias.");
            return;
        }
        for (Equipment equipment : matches) {
            System.out.println(equipment);
            for (Client client : state.clients) {
                if (client.ownsEquipment(equipment.getEquipmentId())) {
                    System.out.println("Cliente: " + client.getName() + " (ID " + client.getClientId() + ")");
                }
            }
        }
    }
}
