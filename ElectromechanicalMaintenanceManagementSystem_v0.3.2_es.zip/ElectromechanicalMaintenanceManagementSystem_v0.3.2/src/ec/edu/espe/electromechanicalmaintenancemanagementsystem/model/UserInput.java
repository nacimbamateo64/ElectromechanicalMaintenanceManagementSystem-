package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

/**
 * ABSTRACTION: contract for any way of asking the user for data.
 * ConsoleInput implements it with a Scanner; a window (Swing/JavaFX), a web form or a
 * scripted test double can implement it too without touching the *Actions classes,
 * which depend only on this interface.
 * Every read method keeps asking until it receives a valid value.
 */
public interface UserInput {
    int readInt(String message);

    int readIntInRange(String message, int min, int max);

    int readNonNegativeInt(String message);

    int readPositiveInt(String message);

    float readNonNegativeFloat(String message);

    String readText(String message);

    /** Letters, spaces, accents, apostrophes and hyphens only. */
    String readName(String message);

    /** Exactly 10 digits starting with 0. */
    String readPhone(String message);

    /** ISO date (YYYY-MM-DD), today or later. */
    String readDate(String message);

    /** Returns the matching element of {@code choices} (case-insensitive match). */
    String readChoice(String message, String... choices);

    boolean readBoolean(String message);
}
