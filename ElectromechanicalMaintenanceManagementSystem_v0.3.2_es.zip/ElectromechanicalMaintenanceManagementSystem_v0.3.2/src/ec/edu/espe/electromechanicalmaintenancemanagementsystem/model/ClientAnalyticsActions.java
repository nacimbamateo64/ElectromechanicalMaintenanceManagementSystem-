package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.List;
import java.util.Optional;

/** Console actions that show the client spending reports. */
public class ClientAnalyticsActions {
    private final ClientSpendingAnalyzer analyzer;

    public ClientAnalyticsActions(SystemState state) {
        this.analyzer = new ClientSpendingAnalyzer(state);
    }

    public void showSpendingPerClient() {
        System.out.println("\nTOTAL GASTADO POR CLIENTE (USD)");
        List<ClientSpending> summaries = analyzer.summarizeSpendingByClient();
        ConsoleOutput.show(summaries);
        System.out.println("Ingresos totales: $" + analyzer.calculateTotalRevenue().toPlainString());
    }

    public void showAverages() {
        System.out.println("\nPROMEDIOS");
        System.out.println("Precio promedio por orden de trabajo: $" + analyzer.calculateAverageOrderPrice().toPlainString());
        System.out.println("Gasto promedio por cliente: $" + analyzer.calculateAverageSpentPerClient().toPlainString());
        System.out.printf("Compras promedio por cliente: %.2f%n", analyzer.calculateAveragePurchasesPerClient());
    }

    public void showLoyaltyGiftRecipient() {
        System.out.println("\nOBSEQUIO DE FIDELIDAD");
        Optional<ClientSpending> mostFrequent = analyzer.findMostFrequentClient();
        if (!mostFrequent.isPresent()) {
            System.out.println("Ningún cliente ha realizado una compra todavía.");
            return;
        }
        System.out.println("El cliente que compra con más frecuencia es:");
        System.out.println(mostFrequent.get());
    }
}
