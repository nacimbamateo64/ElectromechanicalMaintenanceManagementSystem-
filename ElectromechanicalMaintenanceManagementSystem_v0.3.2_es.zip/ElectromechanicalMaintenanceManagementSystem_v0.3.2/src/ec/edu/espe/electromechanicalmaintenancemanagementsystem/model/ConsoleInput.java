package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.time.LocalDate;
import java.util.Scanner;


public class ConsoleInput implements UserInput {
    private final Scanner scanner;

    public ConsoleInput(Scanner scanner) {
        this.scanner = scanner;
    }

    @Override
    public int readInt(String message) {
        while (true) {
            try {
                System.out.print(message);
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException exception) {
                System.out.println("Entrada no válida. Ingrese un número entero.");
            }
        }
    }

    @Override
    public int readIntInRange(String message, int min, int max) {
        while (true) {
            int value = readInt(message);
            if (value >= min && value <= max) {
                return value;
            }
            System.out.println("Ingrese un número entre " + min + " y " + max + ".");
        }
    }

    @Override
    public int readNonNegativeInt(String message) {
        while (true) {
            int value = readInt(message);
            if (value >= 0) return value;
            System.out.println("El valor no puede ser negativo.");
        }
    }

    @Override
    public int readPositiveInt(String message) {
        while (true) {
            int value = readInt(message);
            if (value > 0) {
                return value;
            }
            System.out.println("El valor debe ser mayor que cero.");
        }
    }

    @Override
    public float readNonNegativeFloat(String message) {
        while (true) {
            float value = readFloat(message);
            if (value >= 0) {
                return value;
            }
            System.out.println("El valor no puede ser negativo.");
        }
    }

    @Override
    public String readText(String message) {
        while (true) {
            System.out.print(message);
            String value = scanner.nextLine().trim();
            if (!value.isEmpty()) {
                return value;
            }
            System.out.println("Este campo no puede estar vacío.");
        }
    }

    @Override
    public String readName(String message) {
        while (true) {
            String name = readText(message);
            if (name.matches("[\\p{L}][\\p{L} .'-]*")) {
                return name;
            }
            System.out.println("Use solo letras. Se permiten espacios, tildes, apóstrofes y guiones.");
        }
    }

    @Override
    public String readPhone(String message) {
        while (true) {
            String phone = readText(message);
            if (phone.matches("0[0-9]{9}")) {
                return phone;
            }
            System.out.println("El número de teléfono debe tener exactamente 10 dígitos y empezar con 0.");
        }
    }

    @Override
    public String readDate(String message) {
        while (true) {
            String input = readText(message);
            try {
                LocalDate date = LocalDate.parse(input);
                if (date.isBefore(LocalDate.now())) {
                    System.out.println("La fecha debe ser hoy o posterior.");
                    continue;
                }
                return date.toString();
            } catch (java.time.format.DateTimeParseException exception) {
                System.out.println("Fecha no válida. Use el formato AAAA-MM-DD, por ejemplo 2026-11-27.");
            }
        }
    }

    @Override
    public String readChoice(String message, String... choices) {
        while (true) {
            String value = readText(message);
            for (String choice : choices) {
                if (value.equalsIgnoreCase(choice)) {
                    return choice;
                }
            }
            System.out.println("Opción no válida. Valores permitidos: " + String.join(", ", choices));
        }
    }

    @Override
    public boolean readBoolean(String message) {
        while (true) {
            String value = readText(message);
            if (value.equalsIgnoreCase("sí") || value.equalsIgnoreCase("si") || value.equalsIgnoreCase("s")
                    || value.equalsIgnoreCase("yes") || value.equalsIgnoreCase("y")) {
                return true;
            }
            if (value.equalsIgnoreCase("no") || value.equalsIgnoreCase("n")) {
                return false;
            }
            System.out.println("Ingrese sí o no.");
        }
    }

    private float readFloat(String message) {
        while (true) {
            try {
                System.out.print(message);
                float value = Float.parseFloat(scanner.nextLine().trim().replace(',', '.'));
                if (Float.isFinite(value)) {
                    return value;
                }
                System.out.println("Ingrese un número finito.");
            } catch (NumberFormatException exception) {
                System.out.println("Número no válido. Ejemplo: 12.50");
            }
        }
    }
}
