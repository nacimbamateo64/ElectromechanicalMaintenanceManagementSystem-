package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.ArrayList;


public class SystemState {
    public ArrayList<Client> clients = new ArrayList<>();
    public ArrayList<Equipment> equipments = new ArrayList<>();
    public ArrayList<Technician> technicians = new ArrayList<>();
    public ArrayList<WorkOrder> orders = new ArrayList<>();
    public ArrayList<MaintenanceSchedule> schedules = new ArrayList<>();
    public ArrayList<MaintenanceHistory> histories = new ArrayList<>();
    public ArrayList<Part> parts = new ArrayList<>();
    public ArrayList<SafetyRegulation> regulations = new ArrayList<>();
    public ArrayList<Alert> alerts = new ArrayList<>();
    public ArrayList<Report> reports = new ArrayList<>();
    public ArrayList<QrCode> qrCodes = new ArrayList<>();

    public Client findClient(int id) {
        return Identifiable.findById(clients, id).orElse(null);
    }

    public Equipment findEquipment(int id) {
        return Identifiable.findById(equipments, id).orElse(null);
    }

    public Technician findTechnician(int id) {
        return Identifiable.findById(technicians, id).orElse(null);
    }

    public WorkOrder findOrder(int id) {
        return Identifiable.findById(orders, id).orElse(null);
    }

    public int nextClientId() {
        return Identifiable.nextId(clients);
    }

    /** Also looks at the orders attached to each equipment, so an ID is never reused. */
    public int nextOrderId() {
        int next = Identifiable.nextId(orders);
        for (Equipment equipment : equipments) {
            next = Math.max(next, Identifiable.nextId(equipment.getWorkOrders()));
        }
        return next;
    }

    public int nextEquipmentId() {
        return Identifiable.nextId(equipments);
    }

    public int nextReportId() {
        return Identifiable.nextId(reports);
    }

    public int nextTechnicianId() {
        return Identifiable.nextId(technicians);
    }

    public int nextScheduleId() {
        return Identifiable.nextId(schedules);
    }

    public int nextPartId() {
        return Identifiable.nextId(parts);
    }

    public int nextRegulationId() {
        return Identifiable.nextId(regulations);
    }

    public int nextHistoryId() {
        return Identifiable.nextId(histories);
    }

    public java.util.List<WorkOrder> findOrdersByClient(int clientId) {
        java.util.List<WorkOrder> clientOrders = new ArrayList<>();
        for (WorkOrder order : orders) {
            if (order.belongsToClient(clientId)) clientOrders.add(order);
        }
        return clientOrders;
    }

    public java.util.List<WorkOrder> findPurchases() {
        java.util.List<WorkOrder> purchases = new ArrayList<>();
        for (WorkOrder order : orders) {
            if (order.isPurchase()) purchases.add(order);
        }
        return purchases;
    }

    public int countOpenOrders() {
        int open = 0;
        for (WorkOrder order : orders) {
            if (!order.isClosed()) open++;
        }
        return open;
    }

    public java.util.List<Technician> findAvailableTechnicians() {
        java.util.List<Technician> available = new ArrayList<>();
        for (Technician technician : technicians) {
            if (technician.isAvailable()) available.add(technician);
        }
        return available;
    }
}
