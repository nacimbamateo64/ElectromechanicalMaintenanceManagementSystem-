# MongoDB import files

One file per collection, in MongoDB Extended JSON (array format). Generated from `data/*.json`.

| Collection | Documents | Notes |
|---|---|---|
| clients | 5 | `_class: "Client"`, `parentClass: "Person"` |
| technicians | 1 | `_class: "Technician"`, `parentClass: "Person"` |
| equipments | 1 | |
| qr_codes | 1 | |
| service_catalog | 14 | `_class` = PreventiveService / CorrectiveService / DiagnosticService / EmergencyService, `priceUSD` as Decimal128 |
| work_orders | 10 | `price` as Decimal128, `creationDate` as Date |
| reports | 2 | `generatedDate` as Date |
| parts | 4 | `unitCost` as Decimal128 |
| safety_regulations | 3 | |
| maintenance_history | 2 | |
| maintenance_schedules | 2 | |
| maintenance_tasks | 4 | linked to `partIds` and `regulationIds` |
| alerts | 3 | |

## Conventions
- `_id` = the entity's numeric ID from the Java program (clientId, workOrderId, ...). The original ID field is kept too.
- Money uses Decimal128 (`{"$numberDecimal": "85.00"}`), so it is exact to the cent.
- Dates `YYYY-MM-DD` are stored as real BSON dates at 00:00 UTC.
- Relations are stored as IDs (`equipmentIds`, `technicianId`, `workOrderId`, ...), the same as the Java program.
- Work orders 1-10 are legacy records: they have no client, equipment or service, and their price is `0.00`.

## Import
Use `mongoimport` (MongoDB Database Tools):

```bash
export MONGODB_URI="mongodb+srv://USER:PASSWORD@CLUSTER.mongodb.net"
./import_mongodb.sh maintenance_db
```

On Windows:
```bat
set MONGODB_URI=mongodb+srv://USER:PASSWORD@CLUSTER.mongodb.net
import_mongodb.bat maintenance_db
```

`--drop` replaces each collection, so running it again does not create duplicates.
In MongoDB Compass or Atlas you can also import each file with *Add Data > Import JSON*. Empty files can be skipped.
