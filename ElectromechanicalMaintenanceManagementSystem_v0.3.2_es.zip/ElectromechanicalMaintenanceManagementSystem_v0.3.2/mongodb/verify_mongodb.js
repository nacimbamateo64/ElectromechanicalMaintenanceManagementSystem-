// Run in mongosh:  mongosh "YOUR_URI" --file verify_mongodb.js
const database = db.getSiblingDB("maintenance_db");
const expected = { clients:5, technicians:1, equipments:1, qr_codes:1, service_catalog:14, work_orders:10,
  reports:2, parts:4, safety_regulations:3, maintenance_history:2, maintenance_schedules:2, maintenance_tasks:4, alerts:3 };
let withData = 0;
for (const [name, n] of Object.entries(expected)) {
  const c = database.getCollection(name).countDocuments();
  if (c > 0) withData++;
  print((c === n ? "OK   " : "FAIL ") + name + ": " + c + " (expected " + n + ")");
}
print("\nCollections with data: " + withData + " / 13  (customer asks for at least 10)");
