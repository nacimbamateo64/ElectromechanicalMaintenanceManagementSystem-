#!/usr/bin/env bash
# Usage: MONGODB_URI="mongodb+srv://USER:PASSWORD@CLUSTER.mongodb.net" ./import_mongodb.sh [database]
set -e
DB="${1:-maintenance_db}"
: "${MONGODB_URI:?Set MONGODB_URI first}"
cd "$(dirname "$0")"
for c in clients technicians equipments qr_codes service_catalog work_orders maintenance_tasks maintenance_schedules maintenance_history parts safety_regulations alerts reports; do
  mongoimport --uri "$MONGODB_URI" --db "$DB" --collection "$c" --file "$c.json" --jsonArray --drop
done
