# Guía MongoDB (qué hacer y qué falta)

## Ya está hecho (en este proyecto)
- 13 archivos JSON, uno por colección, TODOS con datos (el cliente pide mínimo 10).
- Scripts de importación: import_mongodb.bat / import_mongodb.sh
- Script de verificación: verify_mongodb.js

## Lo que falta hacer en MongoDB (solo tú puedes, es tu cuenta)
1. Crear cuenta y cluster gratis en MongoDB Atlas (M0).
2. Database Access: crear usuario y contraseña.
3. Network Access: permitir tu IP (o 0.0.0.0/0 solo para pruebas).
4. Connect > Drivers/Compass: copiar el connection string.
5. Importar los datos (script o Compass, ver README_MONGODB.md). Base: maintenance_db
6. Verificar: mongosh "TU_URI" --file verify_mongodb.js  -> debe decir 13 / 13.
7. Tomar capturas de Compass/Atlas mostrando las colecciones con sus documentos.
8. Si el docente lo pide: compartir el URI de solo lectura o las capturas, NUNCA tu contraseña principal.

## Nota importante
El programa Java guarda en archivos JSON (carpeta data/), no se conecta a MongoDB.
La base en MongoDB es la entrega de datos para el cliente. Si te piden que el programa
lea de MongoDB, eso es un cambio de código aparte (driver mongodb-driver-sync).
