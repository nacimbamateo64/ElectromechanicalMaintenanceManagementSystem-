@echo off
REM Usage: set MONGODB_URI=mongodb+srv://USER:PASSWORD@CLUSTER.mongodb.net
REM        import_mongodb.bat [database]
set DB=%1
if "%DB%"=="" set DB=maintenance_db
if "%MONGODB_URI%"=="" (echo Set MONGODB_URI first & exit /b 1)
cd /d "%~dp0"
for %%c in (clients technicians equipments qr_codes service_catalog work_orders maintenance_tasks maintenance_schedules maintenance_history parts safety_regulations alerts reports) do (
  mongoimport --uri "%MONGODB_URI%" --db "%DB%" --collection %%c --file %%c.json --jsonArray --drop
)
