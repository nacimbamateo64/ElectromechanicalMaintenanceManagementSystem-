Electromechanical Maintenance Management System - corrected build

HOW TO BUILD AND RUN (Apache NetBeans / Java Ant)
1. Open this folder as an existing Java Ant project in NetBeans.
2. Run Build Project, then Run Project.
3. In a terminal opened at the project root, the main source can also be compiled with:
   javac -encoding UTF-8 -d out @sources.txt
   (Create sources.txt first with: dir /s /b src\*.java > sources.txt on Windows.)
4. Run from the project root with:
   java -cp out ec.edu.espe.electromechanicalmaintenancemanagementsystem.view.ElectromechanicalMaintenanceManagementSystem

IMPLEMENTED / FIXED
- Console menu has 15 options; option 14 now actually generates maintenance_report.csv.
- Option 15 exits cleanly.
- CSV export uses UTF-8 with BOM for Excel, quotes CSV cells, and exports the in-memory records from all current record lists, including tasks, task parts, and task safety regulations.
- All data is saved as JSON, one file per record type, inside the data/ folder, and loaded on startup:
    clients.json, equipments.json, qr_codes.json, technicians.json,
    maintenance_schedules.json, work_orders.json, maintenance_tasks.json,
    parts.json, safety_regulations.json, maintenance_history.json,
    alerts.json, reports.json
  Relations (client-equipment, equipment-work orders, task-parts, etc.) are stored as IDs and rebuilt on load.
- All JSON code lives in the model package (Json, JsonFileManager, JsonDataStore, SystemState).
  The controller package is intentionally empty.
- The view package contains only Main, which just starts MaintenanceMenu. All classes live in the model package: ConsoleInput/ConsoleOutput
  (console I/O) and the menu options grouped in ClientActions, EquipmentActions, TechnicianActions, WorkOrderActions and RecordActions.
  Business logic (lookups, IDs, CSV export) lives in the model package (SystemState, WorkOrder, CsvExporter).
- A damaged JSON file is not overwritten silently: a copy is kept as <name>.json.corrupt.
- Equipment removal checks that the equipment is actually associated with the selected client. It removes the association only; it does not delete the equipment record from the whole system.
- Uses only standard Java APIs; no JSON or CSV external library is required.

IMPORTANT LIMITATIONS TO KNOW
- CSV records are exported in two columns (Record Type and Record Data). The data column contains each object's readable toString() representation rather than one spreadsheet column per field.
- The supplied JUnit test source files refer to JUnit libraries and testdata CSV fixtures that are not included in this project ZIP. Main application source compilation and console workflow smoke tests were performed, but the existing JUnit suite cannot run as packaged until those dependencies/fixtures are restored.


ADDITIONAL FEATURES (UPDATED)
-----------------------------
- Menu option 16 displays the maintenance service catalogue and estimated prices in USD.
- Creating a work order now requires selecting a catalogue service. The selected service,
  estimated price and equipment ID are stored in the work order.
- Work order prices are persisted in data/work_orders.json and included in work_orders.csv.
- Every application save writes the entity JSON files and refreshes the CSV exports in data/.
- The service catalogue is also stored in data/service_catalog.json and data/service_catalog.csv.
- Prices are indicative estimates in USD. Parts, materials, taxes and special conditions may
  change the final quote; adjust the values in MaintenancePriceCatalog.java as needed.


WORK ORDER FLOW (UPDATED)
-------------------------
- Menu option 5 now follows: choose client -> choose one of THAT client's equipment ->
  service catalogue with prices is displayed -> choose service -> work order is created.
  If the client has no equipment, the program asks to register it first (option 2).
- data/work_orders.json now stores these fields as real JSON properties (not only inside the
  description text): clientId, equipmentId, serviceId, serviceName, price (USD).
  work_orders.csv gets the same columns automatically.
- Work order and equipment IDs are now max+1 instead of list size + 1, so they are not
  reused after deletions.
- Sample work orders 1-10 are legacy records: they have no client, equipment, service or price
  (those fields are null / 0.0). References to technicians that do not exist were set to null;
  the program prints a warning if it finds such a broken reference again.
- The service catalogue is still defined in MaintenancePriceCatalog.java;
  data/service_catalog.json/.csv are output files only.


INHERITANCE, ABSTRACTION AND POLYMORPHISM (v0.3.0)
--------------------------------------------------
New types (all in the model package):
- Identifiable (interface): getId(). Implemented by Person and MaintenanceService.
- Priceable (interface): calculatePrice() : BigDecimal, getFormattedPrice().
  Implemented by MaintenanceService, Part (unitCost x stockQuantity) and WorkOrder.
- Person (abstract class): id, name, abstract getRole() / getDetails(), final describe().
  Client and Technician now EXTEND Person (constructors and getters unchanged:
  getClientId() / getTechnicianId() still work).
- MaintenanceService (abstract class): serviceId, serviceName, basePrice (BigDecimal, exact).
  Abstract getCategory(), getDefaultPriority(), getTaskType().
  Subclasses: PreventiveService, CorrectiveService, DiagnosticService, EmergencyService
  (EmergencyService also overrides requiresImmediateAttention() and describe()).
- MaintenancePriceCatalog now holds a List<MaintenanceService>. Prices are the same 14 values.

Where polymorphism is used:
- Option 5 (create work order): the selected service decides the suggested priority;
  an EmergencyService forces priority "high".
- Option 7 (add task): suggests the task type of the order's service.
- Option 16: price list shows each service's category.
- New option 24: shows clients and technicians together as List<Person> using describe().
- New option 25: price summary through the Priceable interface.
- Exit is now option 26.

JSON changes: clients/technicians have "role"; work_orders has "serviceCategory";
service_catalog has serviceType, category, defaultPriority, taskType, requiresImmediateAttention.

MongoDB: see the mongodb/ folder (Extended JSON, Decimal128 prices, import scripts).
UML: UML_Inheritance_Abstraction_Polymorphism.png (.dot source included).
Tests: test/.../InheritancePolymorphismTest.java (6 tests, all passing).


CLIENT ANALYTICS AND NEW METHODS (v0.3.1)
-----------------------------------------
- New menu options: 26 total spent per client, 27 averages, 28 loyalty gift recipient, 29 exit.
- A "purchase" is a work order that has a client (WorkOrder.isPurchase()). Legacy orders without client are ignored.
- ClientSpendingAnalyzer: total spent per client, average order price, average spent per client,
  average purchases per client, most frequent client (loyalty gift), biggest spender.
- Tie-break for the loyalty gift: more purchases, then more money spent, then lower client ID.
- Every model class received small query/command methods (isClosed(), ownsEquipment(), calculatePartsCost(), ...).

INTERFACES (v0.3.2)
-------------------
New interfaces (all in the model package, see UML_Interfaces.png / .dot):
- UserInput: every read* method the menu needs (readInt, readText, readName, readPhone, readDate...).
  ConsoleInput implements it. ClientActions, EquipmentActions, TechnicianActions, WorkOrderActions,
  SearchActions and MaintenancePriceCatalog.chooseService() depend on the interface, so a window or
  a scripted test double can replace the console without touching them.
- PersistenceStore: load() / save(state). JsonDataStore implements it. MaintenanceMenu depends on the
  interface, so another store (MongoDB, in-memory for tests) can be plugged in.
- DataExporter: export(target, state). CsvDataExporter implements it (it delegates to CsvExporter).
  RecordActions receives a DataExporter (default: CSV).
- Searchable: matchesSearchTerm(term) plus static filter(items, term). Implemented by Client, Technician,
  Equipment, WorkOrder and Part. Option 17 now searches clients, equipment, technicians and work orders
  through this single interface (SearchActions); the matching code that was copied in ClientActions is gone.
- Identifiable (extended): now implemented by EVERY record (Equipment, WorkOrder, MaintenanceTask,
  MaintenanceSchedule, MaintenanceHistory, Part, Alert, Report, SafetyRegulation, QrCode, besides Person and
  MaintenanceService). Static helpers findById() and nextId() replace the repeated search/"max + 1" loops
  in SystemState. CsvExporter skips the new getId() for non-Person records so the CSV columns are unchanged.
- MenuAction / MenuOption: COMMAND pattern. MaintenanceMenu is now a table of options (one line per option);
  numbers are assigned automatically, so the printed menu and the dispatch can no longer get out of sync.

Other changes:
- ElectromechanicalMaintenanceManagementSystem (view) is now only the entry point. The 29-option menu used to
  be duplicated there while MaintenanceMenu was out of date (it exited with 26 and had no options 26-28).
- Technician, schedule, part, safety regulation and history IDs use the next free ID (highest + 1) instead of
  "list size + 1", which repeated an ID when the loaded data had gaps (same fix v0.2.9 made for orders/equipment).
- Option 17 prints "No matches found." instead of nothing when the search has no result.
- Option 17 text changed to "Search clients, equipment, technicians and work orders".

Tests: SearchableTest, IdentifiableTest, MenuInterfacesTest, DataExporterTest (32 tests, all passing).
DataExporterTest also pins the exact CSV column headers of the existing files.
Note: TestData.DATA_SET is "set75" and rows 8-10 of testdata/set75 hold expected values that cannot match the
code (for example "ClosedX"), so 30 of the 136 older tests fail with that data set (same 30 before and after
v0.3.2). With DATA_SET = "set100" all 136 pass. Running them needs junit4 and hamcrest-core on the classpath.
