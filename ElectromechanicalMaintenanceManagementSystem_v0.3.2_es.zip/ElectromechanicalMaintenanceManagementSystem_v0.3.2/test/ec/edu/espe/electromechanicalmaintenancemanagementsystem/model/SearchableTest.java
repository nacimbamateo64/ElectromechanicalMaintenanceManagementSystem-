package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class SearchableTest {

    @Test
    public void clientMatchesByIdNameOrPhoneIgnoringCase() {
        Client client = new Client(7, "Ana Lopez", "0987654321", "Quito");
        assertTrue(client.matchesSearchTerm("7"));
        assertTrue(client.matchesSearchTerm("ANA"));
        assertTrue(client.matchesSearchTerm("0987"));
        assertFalse(client.matchesSearchTerm("55"));
        assertFalse(client.matchesSearchTerm("zzz"));
    }

    @Test
    public void equipmentMatchesByIdNameOrSerial() {
        Equipment equipment = new Equipment(2, "Compresor Atlas", "SN-001", "Planta", "Available");
        assertTrue(equipment.matchesSearchTerm("2"));
        assertTrue(equipment.matchesSearchTerm("atlas"));
        assertTrue(equipment.matchesSearchTerm("sn-001"));
        assertFalse(equipment.matchesSearchTerm("planta"));
    }

    @Test
    public void equipmentWithMissingFieldsDoesNotThrow() {
        Equipment incomplete = new Equipment(3, null, null, "Planta", "Available");
        assertFalse(incomplete.matchesSearchTerm("abc"));
        assertTrue(incomplete.matchesSearchTerm("3"));
    }

    @Test
    public void technicianMatchesByIdNameOrExpertise() {
        Technician technician = new Technician(4, "Luis Mora", "Electrical", true);
        assertTrue(technician.matchesSearchTerm("4"));
        assertTrue(technician.matchesSearchTerm("mora"));
        assertTrue(technician.matchesSearchTerm("ELECTRIC"));
        assertFalse(technician.matchesSearchTerm("mechanical"));
    }

    @Test
    public void workOrderMatchesByIdDescriptionServiceOrStatus() {
        WorkOrder order = new WorkOrder(12, "Bearing noise in pump", "High", "Pending", "2026-11-22");
        order.setServiceName("Bearing replacement");
        assertTrue(order.matchesSearchTerm("12"));
        assertTrue(order.matchesSearchTerm("pump"));
        assertTrue(order.matchesSearchTerm("replacement"));
        assertTrue(order.matchesSearchTerm("PENDING"));
        assertFalse(order.matchesSearchTerm("closed"));
    }

    @Test
    public void partMatchesByIdNameOrSupplier() {
        Part part = new Part(5, "Contactor 25A", 3, 12.5f, "Schneider");
        assertTrue(part.matchesSearchTerm("5"));
        assertTrue(part.matchesSearchTerm("contactor"));
        assertTrue(part.matchesSearchTerm("schneid"));
        assertFalse(part.matchesSearchTerm("siemens"));
    }

    @Test
    public void filterKeepsMatchesInOriginalOrderForAnyKindOfRecord() {
        List<Client> clients = new ArrayList<>(Arrays.asList(
                new Client(1, "Maria Perez", "0911111111", "Quito"),
                new Client(2, "Pedro Gomez", "0922222222", "Cuenca"),
                new Client(3, "Maria Torres", "0933333333", "Loja")));
        List<Client> marias = Searchable.filter(clients, "maria");
        assertEquals(2, marias.size());
        assertEquals(1, marias.get(0).getId());
        assertEquals(3, marias.get(1).getId());

        List<Part> parts = Arrays.asList(new Part(1, "Fuse", 1, 1f, "ABB"), new Part(2, "Relay", 1, 1f, "ABB"));
        assertEquals(2, Searchable.filter(parts, "abb").size());
    }

    @Test
    public void filterIsNullSafe() {
        assertTrue(Searchable.filter(null, "x").isEmpty());
        assertTrue(Searchable.filter(new ArrayList<Client>(), null).isEmpty());
        assertTrue(Searchable.filter(new ArrayList<Client>(), "x").isEmpty());
    }

    @Test
    public void containsIgnoreCaseHandlesNulls() {
        assertTrue(Searchable.containsIgnoreCase("Hello World", "WORLD"));
        assertFalse(Searchable.containsIgnoreCase(null, "a"));
        assertFalse(Searchable.containsIgnoreCase("a", null));
    }

    @Test
    public void unifiedSearchActionFindsTechniciansThroughTheInterface() {
        SystemState state = new SystemState();
        state.technicians.add(new Technician(1, "Luis Mora", "Electrical", true));
        state.technicians.add(new Technician(2, "Ana Vera", "Mechanical", true));
        ScriptedInput input = new ScriptedInput("3", "electr");

        String output = capture(() -> new SearchActions(state, input).search());

        assertTrue(output.contains("Luis Mora"));
        assertFalse(output.contains("Ana Vera"));
    }

    @Test
    public void unifiedSearchActionShowsOwnerOfMatchingEquipment() {
        SystemState state = new SystemState();
        Client client = new Client(4, "Enrique Nacimba", "0976542897", "Amaguana");
        Equipment equipment = new Equipment(1, "Motor", "600", "Guamani", "Available");
        client.addEquipment(equipment);
        state.clients.add(client);
        state.equipments.add(equipment);

        String output = capture(() -> new SearchActions(state, new ScriptedInput("2", "600")).search());

        assertTrue(output.contains("Equipo{idEquipo=1"));
        assertTrue(output.contains("Cliente: Enrique Nacimba (ID 4)"));
    }

    @Test
    public void unifiedSearchActionReportsWhenNothingMatches() {
        SystemState state = new SystemState();
        String output = capture(() -> new SearchActions(state, new ScriptedInput("4", "nothing")).search());
        assertTrue(output.contains("No se encontraron coincidencias."));
    }

    /** Runs the code and returns what it printed to System.out. */
    static String capture(Runnable code) {
        PrintStream original = System.out;
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        try {
            System.setOut(new PrintStream(buffer, true, java.nio.charset.StandardCharsets.UTF_8));
            code.run();
        } finally {
            System.setOut(original);
        }
        return new String(buffer.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
    }
}
