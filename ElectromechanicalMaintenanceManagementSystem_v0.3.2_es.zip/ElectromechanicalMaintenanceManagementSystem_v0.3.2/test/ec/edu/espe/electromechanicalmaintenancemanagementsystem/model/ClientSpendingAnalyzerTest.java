package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.math.BigDecimal;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ClientSpendingAnalyzerTest {
    private SystemState state;
    private ClientSpendingAnalyzer analyzer;
    private Client ana;
    private Client luis;
    private Client eva;

    @Before
    public void setUp() {
        state = new SystemState();
        ana = new Client(1, "Ana", "0999999999", "Quito");
        luis = new Client(2, "Luis", "0988888888", "Sangolqui");
        eva = new Client(3, "Eva", "0977777777", "Cuenca");
        state.clients.add(ana);
        state.clients.add(luis);
        state.clients.add(eva);
        state.orders.add(buildOrder(1, ana.getClientId(), 100.00));
        state.orders.add(buildOrder(2, ana.getClientId(), 50.50));
        state.orders.add(buildOrder(3, luis.getClientId(), 400.00));
        state.orders.add(buildOrder(4, ana.getClientId(), 20.00));
        state.orders.add(buildOrder(5, 0, 999.00));
        analyzer = new ClientSpendingAnalyzer(state);
    }

    private WorkOrder buildOrder(int id, int clientId, double price) {
        WorkOrder order = new WorkOrder(id, "Equipment ID: 1", "Medium", "Closed", "2026-11-01");
        order.setClientId(clientId);
        order.setPrice(price);
        return order;
    }

    @Test
    public void calculatesTotalSpentByClient() {
        assertEquals(new BigDecimal("170.50"), analyzer.calculateTotalSpentBy(ana));
        assertEquals(new BigDecimal("0.00"), analyzer.calculateTotalSpentBy(eva));
    }

    @Test
    public void ordersWithoutClientAreNotPurchases() {
        assertEquals(new BigDecimal("570.50"), analyzer.calculateTotalRevenue());
    }

    @Test
    public void calculatesAverages() {
        assertEquals(new BigDecimal("142.63"), analyzer.calculateAverageOrderPrice());
        assertEquals(new BigDecimal("190.17"), analyzer.calculateAverageSpentPerClient());
        assertEquals(4.0 / 3, analyzer.calculateAveragePurchasesPerClient(), 0.0001);
    }

    @Test
    public void findsTheClientWhoBuysTheMostOften() {
        assertEquals(ana, analyzer.findLoyaltyGiftRecipient().get());
    }

    @Test
    public void findsTheBiggestSpender() {
        assertEquals(luis, analyzer.findBiggestSpender().get().getClient());
    }

    @Test
    public void withoutPurchasesThereIsNoRecipientAndAveragesAreZero() {
        ClientSpendingAnalyzer emptyAnalyzer = new ClientSpendingAnalyzer(new SystemState());
        assertFalse(emptyAnalyzer.findLoyaltyGiftRecipient().isPresent());
        assertEquals(0, emptyAnalyzer.calculateAverageOrderPrice().signum());
        assertEquals(0.0, emptyAnalyzer.calculateAveragePurchasesPerClient(), 0.0);
    }

    @Test
    public void summaryIsSortedByTotalSpentDescending() {
        assertEquals(luis, analyzer.summarizeSpendingByClient().get(0).getClient());
        assertEquals(eva, analyzer.summarizeSpendingByClient().get(2).getClient());
    }
}
