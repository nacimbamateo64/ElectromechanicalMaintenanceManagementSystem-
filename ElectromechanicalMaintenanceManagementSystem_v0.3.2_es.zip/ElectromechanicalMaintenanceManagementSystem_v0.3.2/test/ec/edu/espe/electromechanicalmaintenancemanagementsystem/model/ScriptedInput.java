package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;

/**
 * Test double for the UserInput interface: answers come from a fixed script, no console involved.
 * It only exists because the *Actions classes depend on the interface and not on ConsoleInput.
 */
class ScriptedInput implements UserInput {
    private final Deque<String> answers = new ArrayDeque<>();

    ScriptedInput(String... answers) {
        this.answers.addAll(Arrays.asList(answers));
    }

    private String next() {
        if (answers.isEmpty()) {
            throw new IllegalStateException("The script ran out of answers.");
        }
        return answers.poll();
    }

    @Override public int readInt(String message) { return Integer.parseInt(next()); }
    @Override public int readIntInRange(String message, int min, int max) { return Integer.parseInt(next()); }
    @Override public int readNonNegativeInt(String message) { return Integer.parseInt(next()); }
    @Override public int readPositiveInt(String message) { return Integer.parseInt(next()); }
    @Override public float readNonNegativeFloat(String message) { return Float.parseFloat(next()); }
    @Override public String readText(String message) { return next(); }
    @Override public String readName(String message) { return next(); }
    @Override public String readPhone(String message) { return next(); }
    @Override public String readDate(String message) { return next(); }
    @Override public String readChoice(String message, String... choices) { return next(); }
    @Override public boolean readBoolean(String message) { return next().equalsIgnoreCase("yes"); }
}
