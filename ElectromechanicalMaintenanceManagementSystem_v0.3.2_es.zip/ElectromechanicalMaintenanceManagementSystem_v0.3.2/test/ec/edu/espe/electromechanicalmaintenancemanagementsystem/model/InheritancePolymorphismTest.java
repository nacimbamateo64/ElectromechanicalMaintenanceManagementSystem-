package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class InheritancePolymorphismTest {

    @Test
    public void personAndServiceAreAbstract() {
        assertTrue(Modifier.isAbstract(Person.class.getModifiers()));
        assertTrue(Modifier.isAbstract(MaintenanceService.class.getModifiers()));
        assertTrue(Identifiable.class.isInterface());
        assertTrue(Priceable.class.isInterface());
    }

    @Test
    public void clientAndTechnicianInheritFromPerson() {
        Person client = new Client(7, "ESPE", "0999999999", "Sangolqui");
        Person technician = new Technician(3, "Luis", "Electrical", true);
        assertEquals(7, client.getId());
        assertEquals(7, ((Client) client).getClientId());
        assertEquals(3, ((Technician) technician).getTechnicianId());
        assertEquals("ESPE", client.getName());
    }

    @Test
    public void personDescribeIsPolymorphic() {
        List<Person> people = new ArrayList<>();
        people.add(new Client(1, "Ana", "0991", "Quito"));
        people.add(new Technician(2, "Luis", "Motors", false));
        assertEquals("Client #1 - Ana | Contacto: 0991, Dirección: Quito, Equipos: 0", people.get(0).describe());
        assertEquals("Technician #2 - Luis | Especialidad: Motors, Disponible: no", people.get(1).describe());
    }

    @Test
    public void catalogKeepsExactPricesAndSubclasses() {
        assertEquals(14, MaintenancePriceCatalog.serviceCount());
        MaintenanceService first = MaintenancePriceCatalog.findById(1);
        assertTrue(first instanceof CorrectiveService);
        assertEquals(new BigDecimal("85.00"), first.calculatePrice());
        MaintenanceService emergency = MaintenancePriceCatalog.findById(12);
        assertTrue(emergency instanceof EmergencyService);
        assertTrue(emergency.requiresImmediateAttention());
        assertEquals("high", emergency.getDefaultPriority());
        assertFalse(MaintenancePriceCatalog.findById(3).requiresImmediateAttention());
        assertEquals("Preventivo", MaintenancePriceCatalog.findById(3).getCategory());
        assertEquals("Diagnóstico", MaintenancePriceCatalog.findById(14).getCategory());
        assertEquals(35.0, MaintenancePriceCatalog.servicePrice(13), 0.0);
    }

    @Test
    public void priceableIsPolymorphic() {
        WorkOrder order = new WorkOrder(1, "Test", "low", "Pending", "2026-11-21");
        order.applyService(MaintenancePriceCatalog.findById(10));
        Part part = new Part(1, "Bearing", 3, 12.5f, "Supplier");
        List<Priceable> items = new ArrayList<>();
        items.add(order);
        items.add(part);
        items.add(MaintenancePriceCatalog.findById(2));
        BigDecimal total = BigDecimal.ZERO;
        for (Priceable item : items) {
            total = total.add(item.calculatePrice());
        }
        assertEquals(new BigDecimal("152.50"), total);
        assertEquals("Mantenimiento de generadores", order.getServiceName());
        assertEquals("Preventivo", order.getServiceCategory());
        assertEquals("$90.00 USD", order.getFormattedPrice());
    }

    @Test(expected = IllegalArgumentException.class)
    public void serviceRejectsMoreThanTwoDecimals() {
        new PreventiveService(99, "Bad price", "10.005");
    }
}
