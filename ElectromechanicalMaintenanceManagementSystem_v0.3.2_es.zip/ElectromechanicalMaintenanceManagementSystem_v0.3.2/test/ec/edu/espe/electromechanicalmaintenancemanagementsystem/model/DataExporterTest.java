package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class DataExporterTest {

    /** DataExporter test double that records the call instead of writing files. */
    private static class RecordingExporter implements DataExporter {
        final List<String> targets = new ArrayList<>();
        SystemState exported;

        @Override
        public void export(String target, SystemState state) {
            targets.add(target);
            exported = state;
        }
    }

    @Test
    public void recordActionsExportsThroughTheInterface() {
        SystemState state = new SystemState();
        RecordingExporter exporter = new RecordingExporter();
        new RecordActions(state, exporter).exportCsv();
        assertEquals(1, exporter.targets.size());
        assertEquals("maintenance_report.csv", exporter.targets.get(0));
        assertSame(state, exporter.exported);
    }

    @Test
    public void csvDataExporterIsADataExporterThatWritesTheCsvFiles() throws IOException {
        Path folder = Files.createTempDirectory("exporter-test");
        try {
            SystemState state = sampleState();
            DataExporter exporter = new CsvDataExporter();
            SearchableTest.capture(() -> exporter.export(folder.resolve("maintenance_report.csv").toString(), state));
            assertTrue(Files.exists(folder.resolve("clients.csv")));
            assertTrue(Files.exists(folder.resolve("equipments.csv")));
            assertTrue(Files.exists(folder.resolve("work_orders.csv")));
        } finally {
            deleteRecursively(folder);
        }
    }

    /**
     * Regression: making every record Identifiable adds getId(), which must NOT add a new column.
     * These headers are exactly the ones produced before the interface existed.
     */
    @Test
    public void csvColumnsAreUnchangedAfterIdentifiableWasAddedToEveryRecord() throws IOException {
        Path folder = Files.createTempDirectory("csv-schema-test");
        try {
            SystemState state = sampleState();
            SearchableTest.capture(() -> new CsvDataExporter().export(folder.resolve("x.csv").toString(), state));
            assertEquals("\"Client Id\",\"Id\",\"Address\",\"Contact Info\",\"Details\",\"Name\",\"Role\"",
                    header(folder, "clients.csv"));
            assertEquals("\"Id\",\"Technician Id\",\"Availability Status\",\"Available\",\"Details\",\"Expertise\",\"Name\",\"Role\"",
                    header(folder, "technicians.csv"));
            assertEquals("\"Equipment Id\",\"Location\",\"Name\",\"Serial Number\",\"Status\"",
                    header(folder, "equipments.csv"));
            assertEquals("\"Client Id\",\"Equipment Id\",\"Service Id\",\"Work Order Id\",\"Closed\",\"Creation Date\","
                    + "\"Description\",\"Formatted Price\",\"Price\",\"Priority\",\"Purchase\",\"Service Category\","
                    + "\"Service Name\",\"Status\"", header(folder, "work_orders.csv"));
            assertEquals("\"Part Id\",\"Formatted Price\",\"In Stock\",\"Name\",\"Stock Quantity\",\"Supplier\",\"Unit Cost\"",
                    header(folder, "parts.csv"));
            assertEquals("\"Task Id\",\"Completed\",\"Estimated Duration\",\"Pending\",\"Task Description\",\"Task Type\"",
                    header(folder, "maintenance_tasks.csv"));
        } finally {
            deleteRecursively(folder);
        }
    }

    private static SystemState sampleState() {
        SystemState state = new SystemState();
        state.clients.add(new Client(1, "Ana Lopez", "0987654321", "Quito"));
        state.technicians.add(new Technician(1, "Luis Mora", "Electrical", true));
        state.equipments.add(new Equipment(1, "Motor", "600", "Planta", "Available"));
        WorkOrder order = new WorkOrder(1, "Check", "High", "Pending", "2026-01-01");
        order.createTask();
        state.orders.add(order);
        state.parts.add(new Part(1, "Fuse", 2, 1.5f, "ABB"));
        return state;
    }

    private static String header(Path folder, String file) throws IOException {
        String firstLine = Files.readAllLines(folder.resolve(file), StandardCharsets.UTF_8).get(0);
        return firstLine.replace("\uFEFF", "");
    }

    private static void deleteRecursively(Path folder) throws IOException {
        try (java.util.stream.Stream<Path> paths = Files.walk(folder)) {
            paths.sorted(Comparator.reverseOrder()).forEach(path -> path.toFile().delete());
        }
    }
}
