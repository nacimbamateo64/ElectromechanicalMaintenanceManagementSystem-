package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.junit.Test;
import static org.junit.Assert.*;

public class IdentifiableTest {

    @Test
    public void everyRecordOfTheSystemIsIdentifiable() {
        List<Identifiable> records = Arrays.asList(
                new Client(1, "A", "0900000000", "x"),
                new Technician(2, "B", "e", true),
                new Equipment(3, "E", "S", "L", "Available"),
                new WorkOrder(4, "d", "High", "Pending", "2026-01-01"),
                new MaintenanceTask(5, "t", "Preventive", 1f, false),
                new Part(6, "p", 1, 1f, "s"),
                new SafetyRegulation(7, "r", "d", "High"),
                new MaintenanceHistory(8, "2026-01-01", "Preventive", "d"),
                new MaintenanceSchedule(9, "Monthly", "2026-01-01", true),
                new Alert(10, "m", "High", false),
                new Report(11, "Work order", "2026-01-01", "c"),
                new QrCode(12, "code", "url"),
                new PreventiveService(13, "svc", "10.00"));
        for (int i = 0; i < records.size(); i++) {
            assertEquals(i + 1, records.get(i).getId());
        }
    }

    @Test
    public void findByIdWorksOnAnyCollectionOfIdentifiables() {
        List<Equipment> equipments = new ArrayList<>(Arrays.asList(
                new Equipment(1, "A", "S1", "L", "Available"),
                new Equipment(5, "B", "S5", "L", "Available")));
        Optional<Equipment> found = Identifiable.findById(equipments, 5);
        assertTrue(found.isPresent());
        assertEquals("B", found.get().getName());
        assertFalse(Identifiable.findById(equipments, 3).isPresent());
        assertFalse(Identifiable.findById(new ArrayList<Part>(), 1).isPresent());
    }

    @Test
    public void nextIdIsHighestPlusOneAndStartsAtOne() {
        assertEquals(1, Identifiable.nextId(new ArrayList<Technician>()));
        List<Technician> withGap = Arrays.asList(
                new Technician(1, "A", "e", true), new Technician(3, "B", "e", true));
        // size + 1 would give 3, which already exists
        assertEquals(4, Identifiable.nextId(withGap));
    }

    @Test
    public void systemStateLookupsUseTheInterface() {
        SystemState state = new SystemState();
        state.clients.add(new Client(2, "A", "0900000000", "x"));
        state.technicians.add(new Technician(4, "T", "e", true));
        state.equipments.add(new Equipment(6, "E", "S", "L", "Available"));
        state.orders.add(new WorkOrder(8, "d", "High", "Pending", "2026-01-01"));
        assertEquals("A", state.findClient(2).getName());
        assertEquals("T", state.findTechnician(4).getName());
        assertEquals("E", state.findEquipment(6).getName());
        assertEquals("d", state.findOrder(8).getDescription());
        assertNull(state.findClient(99));
        assertNull(state.findTechnician(99));
        assertNull(state.findEquipment(99));
        assertNull(state.findOrder(99));
    }

    @Test
    public void nextOrderIdAlsoConsidersOrdersAttachedToEquipment() {
        SystemState state = new SystemState();
        state.orders.add(new WorkOrder(3, "d", "High", "Pending", "2026-01-01"));
        Equipment equipment = new Equipment(1, "E", "S", "L", "Available");
        equipment.attachWorkOrder(new WorkOrder(9, "d", "High", "Pending", "2026-01-01"));
        state.equipments.add(equipment);
        assertEquals(10, state.nextOrderId());
    }

    @Test
    public void nextIdsOfEveryRecordTypeSkipGaps() {
        SystemState state = new SystemState();
        assertEquals(1, state.nextClientId());
        assertEquals(1, state.nextTechnicianId());
        assertEquals(1, state.nextScheduleId());
        assertEquals(1, state.nextPartId());
        assertEquals(1, state.nextRegulationId());
        assertEquals(1, state.nextHistoryId());
        state.technicians.add(new Technician(1, "A", "e", true));
        state.technicians.add(new Technician(3, "B", "e", true));
        state.schedules.add(new MaintenanceSchedule(5, "Monthly", "2026-01-01", true));
        state.parts.add(new Part(7, "p", 1, 1f, "s"));
        state.regulations.add(new SafetyRegulation(2, "r", "d", "Low"));
        state.histories.add(new MaintenanceHistory(4, "2026-01-01", "Preventive", "d"));
        assertEquals(4, state.nextTechnicianId());
        assertEquals(6, state.nextScheduleId());
        assertEquals(8, state.nextPartId());
        assertEquals(3, state.nextRegulationId());
        assertEquals(5, state.nextHistoryId());
    }

    @Test
    public void registeringATechnicianAfterAGapDoesNotRepeatAnId() {
        SystemState state = new SystemState();
        state.technicians.add(new Technician(1, "A", "e", true));
        state.technicians.add(new Technician(3, "B", "e", true));
        new TechnicianActions(state, new ScriptedInput("Carlos Ruiz", "Hydraulics")).register();
        assertEquals(3, state.technicians.size());
        assertEquals(4, state.technicians.get(2).getTechnicianId());
    }
}
