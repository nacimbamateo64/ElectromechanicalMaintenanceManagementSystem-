package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Standard service catalogue. Prices are illustrative USD estimates and can be adjusted. */
public final class MaintenancePriceCatalog {
    private static final String[][] SERVICES = {
        {"Run motor / motor rewinding (small motor)", "85.00"},
        {"Motor inspection and diagnosis", "25.00"},
        {"Preventive maintenance of electric motor", "45.00"},
        {"Bearing replacement", "55.00"},
        {"Electrical wiring repair", "40.00"},
        {"Pump repair and maintenance", "65.00"},
        {"Industrial fan maintenance", "50.00"},
        {"Control panel inspection", "35.00"},
        {"Contactor or relay replacement (labor)", "30.00"},
        {"Generator maintenance", "90.00"},
        {"Alignment and vibration inspection", "60.00"},
        {"Emergency technical visit", "75.00"},
        {"Cleaning and lubrication", "20.00"},
        {"Insulation test", "35.00"}
    };

    private MaintenancePriceCatalog() { }

    public static void showPrices() {
        System.out.println("\n===== MAINTENANCE SERVICE PRICE LIST (USD) =====");
        System.out.printf("%-4s %-55s %10s%n", "No.", "Service", "Price");
        System.out.println("--------------------------------------------------------------------------");
        for (int i = 0; i < SERVICES.length; i++) {
            System.out.printf("%-4d %-55s $%9s%n", i + 1, SERVICES[i][0], SERVICES[i][1]);
        }
        System.out.println("\nPrices are estimates in USD. Parts, materials and taxes may be charged separately.");
    }

    public static int chooseService(ConsoleInput input) {
        showPrices();
        return input.readIntInRange("Choose the maintenance service: ", 1, SERVICES.length) - 1;
    }

    public static int serviceCount() {
        return SERVICES.length;
    }

    /** Catalogue ID of the service at the given zero-based index (IDs start at 1). */
    public static int serviceId(int index) {
        return index + 1;
    }

    public static String serviceName(int index) {
        return SERVICES[index][0];
    }

    public static double servicePrice(int index) {
        return Double.parseDouble(SERVICES[index][1]);
    }

    public static void save(Path directory) {
        List<Map<String, Object>> rows = new ArrayList<>();
        for (int i = 0; i < SERVICES.length; i++) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("serviceId", i + 1);
            row.put("serviceName", SERVICES[i][0]);
            row.put("priceUSD", servicePrice(i));
            rows.add(row);
        }
        new JsonFileManager(directory.resolve("service_catalog.json")).writeObjects(rows);
        Path csv = directory.resolve("service_catalog.csv");
        try {
            Files.createDirectories(directory);
            try (BufferedWriter writer = Files.newBufferedWriter(csv, StandardCharsets.UTF_8)) {
                writer.write("Service ID,Service Name,Price USD");
                writer.newLine();
                for (Map<String, Object> row : rows) {
                    String name = String.valueOf(row.get("serviceName")).replace("\"", "\"\"");
                    writer.write(row.get("serviceId") + ",\"" + name + "\"," + row.get("priceUSD"));
                    writer.newLine();
                }
            }
        } catch (IOException exception) {
            System.out.println("Could not export service catalogue CSV: " + exception.getMessage());
        }
    }
}
