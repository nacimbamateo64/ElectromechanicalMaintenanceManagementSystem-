package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.ArrayList;
import java.util.List;

public class WorkOrder implements java.io.Serializable {
    private int workOrderId;
    private String description;
    private String priority;
    private String status;
    private String creationDate;
    private double price;
    private int clientId;
    private int equipmentId;
    private int serviceId;
    private String serviceName = "";

    private Technician technician;
    private List<MaintenanceTask> tasks = new ArrayList<>();
    private List<Alert> alerts = new ArrayList<>();
    private List<Report> reports = new ArrayList<>();

    public WorkOrder(int workOrderId, String description, String priority, String status, String creationDate) {
        this.workOrderId = workOrderId;
        this.description = description;
        this.priority = priority;
        this.status = status;
        this.creationDate = creationDate;
    }

    public int getWorkOrderId() {
        return workOrderId;
    }
    public void setWorkOrderId(int workOrderId) {
        this.workOrderId = workOrderId;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    public String getPriority() {
        return priority;
    }
    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreationDate() {
        return creationDate;
    }
    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if (price < 0 || !Double.isFinite(price)) {
            throw new IllegalArgumentException("Price must be a non-negative finite value.");
        }
        this.price = price;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public int getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(int equipmentId) {
        this.equipmentId = equipmentId;
    }

    public int getServiceId() {
        return serviceId;
    }

    public void setServiceId(int serviceId) {
        this.serviceId = serviceId;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName == null ? "" : serviceName;
    }

    public Technician getTechnician() {
        return technician;
    }

    public List<MaintenanceTask> getTasks() {
        return new ArrayList<>(tasks);
    }

    public List<Alert> getAlerts() {
        return new ArrayList<>(alerts);
    }

    public List<Report> getReports() {
        return new ArrayList<>(reports);
    }

    public void assignTechnician(Technician technician) {
        this.technician = technician;
    }

    public void addTask(MaintenanceTask task) {
        if (task != null && !tasks.contains(task)) tasks.add(task);
    }

    public void addAlert(Alert alert) {
        if (alert != null && !alerts.contains(alert)) alerts.add(alert);
    }

    public void addReport(Report report) {
        if (report != null && !reports.contains(report)) reports.add(report);
    }

    public MaintenanceTask createTask() {
        MaintenanceTask task = new MaintenanceTask(tasks.size() + 1, "General inspection", "Preventive", 1.0f, false);
        tasks.add(task);
        return task;
    }

    public Alert createAlert() {
        Alert alert = new Alert(alerts.size() + 1, "Inspection required", "Medium", false);
        alerts.add(alert);
        return alert;
    }

    public Report createReport() {
        Report report = new Report(reports.size() + 1, "Work order", java.time.LocalDate.now().toString(), description + " - " + status);
        reports.add(report);
        return report;
    }

    public MaintenanceTask findTask(int taskId) {
        for (MaintenanceTask task : tasks) {
            if (task.getTaskId() == taskId) return task;
        }
        return null;
    }

    /** Equipment ID written in the description as "Equipment ID: n", or -1 when absent. */
    public int extractEquipmentId() {
        if (equipmentId > 0) {
            return equipmentId;
        }
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("Equipment ID: (\\d+)").matcher(description);
        return matcher.find() ? Integer.parseInt(matcher.group(1)) : -1;
    }

    /** Description plus every task and part used, for the maintenance history entry. */
    public String buildMaintenanceDetails() {
        StringBuilder details = new StringBuilder(description);
        for (MaintenanceTask task : tasks) {
            details.append(" | Task: ").append(task.getTaskDescription());
            for (Part part : task.getParts()) {
                details.append(" | Part: ").append(part.getName()).append(" x ").append(part.getStockQuantity());
            }
        }
        return details.toString();
    }

    public void closeOrder() {
        for (MaintenanceTask task : tasks) {
            if (!task.getIsCompleted()) return;
        }
        status = "Closed";
        if (technician != null) technician.setAvailabilityStatus(true);
    }

    @Override
    public String toString() {
        return "WorkOrder{" + "workOrderId=" + workOrderId + ", " + "description=" + description + ", " + "priority=" + priority + ", " + "status=" + status + ", " + "creationDate=" + creationDate + ", " + "price=" + price + "}";
    }
}
