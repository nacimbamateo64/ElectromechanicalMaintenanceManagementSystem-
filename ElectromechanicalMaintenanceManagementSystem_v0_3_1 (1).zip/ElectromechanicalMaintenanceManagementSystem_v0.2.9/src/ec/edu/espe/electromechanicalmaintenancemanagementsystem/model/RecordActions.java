package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import static ec.edu.espe.electromechanicalmaintenancemanagementsystem.model.ConsoleOutput.show;


/** Console actions that show or export all records. */
public class RecordActions {
    private final SystemState state;

    public RecordActions(SystemState state) {
        this.state = state;
    }

    public void showAll() {
        System.out.println("\nCLIENTS");
        show(state.clients);
        System.out.println("\nEQUIPMENT");
        show(state.equipments);
        System.out.println("\nQR CODES");
        show(state.qrCodes);
        System.out.println("\nTECHNICIANS");
        show(state.technicians);
        System.out.println("\nMAINTENANCE SCHEDULES");
        show(state.schedules);
        System.out.println("\nWORK ORDERS");
        show(state.orders);
        for (WorkOrder order : state.orders) {
            System.out.println("Tasks for work order " + order.getWorkOrderId());
            show(order.getTasks());
        }
        System.out.println("\nPARTS");
        show(state.parts);
        System.out.println("\nSAFETY REGULATIONS");
        show(state.regulations);
        System.out.println("\nMAINTENANCE HISTORIES");
        show(state.histories);
        System.out.println("\nALERTS");
        show(state.alerts);
        System.out.println("\nREPORTS");
        show(state.reports);
    }

    /** POLYMORPHISM: clients and technicians handled through their common parent Person. */
    public void showPeople() {
        java.util.List<Person> people = new java.util.ArrayList<>();
        people.addAll(state.clients);
        people.addAll(state.technicians);
        System.out.println("\nPEOPLE REGISTERED (" + people.size() + ")");
        if (people.isEmpty()) {
            System.out.println("No records.");
        }
        for (Person person : people) {
            System.out.println(person.describe());
        }
    }

    /** POLYMORPHISM: services, work orders and parts priced through the Priceable interface. */
    public void showPriceSummary() {
        java.math.BigDecimal ordersTotal = java.math.BigDecimal.ZERO;
        java.math.BigDecimal partsTotal = java.math.BigDecimal.ZERO;
        System.out.println("\nPRICE SUMMARY (USD)");
        for (Priceable order : state.orders) {
            ordersTotal = ordersTotal.add(order.calculatePrice());
        }
        for (Priceable part : state.parts) {
            partsTotal = partsTotal.add(part.calculatePrice());
        }
        java.util.Map<String, Integer> byCategory = new java.util.LinkedHashMap<>();
        for (MaintenanceService service : MaintenancePriceCatalog.getServices()) {
            byCategory.merge(service.getCategory(), 1, Integer::sum);
        }
        System.out.println("Catalogue services by category: " + byCategory);
        System.out.println("Work orders (" + state.orders.size() + "): $" + ordersTotal.setScale(2).toPlainString());
        System.out.println("Parts in stock (" + state.parts.size() + "): $" + partsTotal.setScale(2).toPlainString());
    }

    public void exportCsv() {
        CsvExporter.export("maintenance_report.csv", state);
    }
}
