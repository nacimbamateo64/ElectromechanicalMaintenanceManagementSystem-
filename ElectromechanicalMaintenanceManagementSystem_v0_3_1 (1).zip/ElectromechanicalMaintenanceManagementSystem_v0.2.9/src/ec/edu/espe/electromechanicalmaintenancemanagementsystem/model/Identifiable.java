package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

/**
 * ABSTRACTION: contract for every entity that has a unique numeric identifier.
 * Implemented by Person (Client, Technician) and MaintenanceService.
 */
public interface Identifiable {
    int getId();
}
