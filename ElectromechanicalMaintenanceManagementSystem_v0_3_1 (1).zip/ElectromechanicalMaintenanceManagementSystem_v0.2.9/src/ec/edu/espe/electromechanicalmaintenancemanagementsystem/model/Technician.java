package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.ArrayList;
import java.util.List;

/** INHERITANCE: a Technician is a Person. POLYMORPHISM: overrides getRole() and getDetails(). */
public class Technician extends Person {
    private String expertise;
    private boolean availabilityStatus;

    private List<MaintenanceHistory> reviewedHistories = new ArrayList<>();

    public Technician(int technicianId, String name, String expertise, boolean availabilityStatus) {
        super(technicianId, name);
        this.expertise = expertise;
        this.availabilityStatus = availabilityStatus;
    }

    public int getTechnicianId() {
        return getId();
    }
    public void setTechnicianId(int technicianId) {
        setId(technicianId);
    }

    public String getExpertise() {
        return expertise;
    }
    public void setExpertise(String expertise) {
        this.expertise = expertise;
    }

    public boolean getAvailabilityStatus() {
        return availabilityStatus;
    }
    public void setAvailabilityStatus(boolean availabilityStatus) {
        this.availabilityStatus = availabilityStatus;
    }

    public List<MaintenanceHistory> getReviewedHistories() {
        return new ArrayList<>(reviewedHistories);
    }

    public void acceptWorkOrder(WorkOrder order) {
        if (order != null && availabilityStatus) {
            order.assignTechnician(this);
            availabilityStatus = false;
        }
    }

    public void reviewHistory(MaintenanceHistory history) {
        if (history != null && !reviewedHistories.contains(history)) reviewedHistories.add(history);
    }

    @Override
    public String getRole() {
        return "Technician";
    }

    @Override
    public String getDetails() {
        return "Expertise: " + expertise + ", Available: " + (availabilityStatus ? "yes" : "no");
    }

    public boolean isAvailable() {
        return availabilityStatus;
    }

    public void markAvailable() {
        availabilityStatus = true;
    }

    public void markUnavailable() {
        availabilityStatus = false;
    }

    public boolean hasExpertise(String requiredExpertise) {
        return expertise != null && expertise.equalsIgnoreCase(requiredExpertise);
    }

    public int countReviewedHistories() {
        return reviewedHistories.size();
    }

    @Override
    public String toString() {
        return "Technician{" + "technicianId=" + getId() + ", " + "name=" + getName() + ", " + "expertise=" + expertise + ", " + "availabilityStatus=" + availabilityStatus + "}";
    }
}
