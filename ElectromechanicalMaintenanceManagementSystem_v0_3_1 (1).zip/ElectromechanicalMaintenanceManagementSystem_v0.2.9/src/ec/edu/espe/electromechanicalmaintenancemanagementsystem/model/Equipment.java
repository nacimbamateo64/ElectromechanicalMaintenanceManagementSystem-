package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.util.ArrayList;
import java.util.List;

public class Equipment implements java.io.Serializable {
    private int equipmentId;
    private String name;
    private String serialNumber;
    private String location;
    private String status;

    private QrCode qrCode;
    private List<MaintenanceHistory> maintenanceHistories = new ArrayList<>();
    private List<MaintenanceSchedule> maintenanceSchedules = new ArrayList<>();
    private List<WorkOrder> workOrders = new ArrayList<>();

    public Equipment(int equipmentId, String name, String serialNumber, String location, String status) {
        this.equipmentId = equipmentId;
        this.name = name;
        this.serialNumber = serialNumber;
        this.location = location;
        this.status = status;
    }

    public int getEquipmentId() {
        return equipmentId;
    }
    public void setEquipmentId(int equipmentId) {
        this.equipmentId = equipmentId;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getSerialNumber() {
        return serialNumber;
    }
    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getLocation() {
        return location;
    }
    public void setLocation(String location) {
        this.location = location;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public QrCode getQrCode() {
        return qrCode;
    }

    public List<MaintenanceHistory> getMaintenanceHistories() {
        return new ArrayList<>(maintenanceHistories);
    }

    public List<MaintenanceSchedule> getMaintenanceSchedules() {
        return new ArrayList<>(maintenanceSchedules);
    }

    public List<WorkOrder> getWorkOrders() {
        return new ArrayList<>(workOrders);
    }

    public void updateStatus(String status) {
        this.status = status;
    }

    public QrCode createQrCode() {
        if (qrCode == null) {
            qrCode = new QrCode(equipmentId, serialNumber, "https://maintenance.local/equipment/" + equipmentId);
        }
        return qrCode;
    }

    public WorkOrder requestMaintenanceOrder() {
        WorkOrder order = new WorkOrder(workOrders.size() + 1, "Maintenance for " + name, "Medium", "Pending", java.time.LocalDate.now().toString());
        workOrders.add(order);
        return order;
    }

    public void assignSchedule(MaintenanceSchedule schedule) {
        if (schedule != null && !maintenanceSchedules.contains(schedule)) maintenanceSchedules.add(schedule);
    }

    public void attachHistory(MaintenanceHistory history) {
        if (history != null) maintenanceHistories.add(history);
    }

    public void attachQrCode(QrCode qrCode) {
        this.qrCode = qrCode;
    }

    public void attachWorkOrder(WorkOrder order) {
        if (order != null && !workOrders.contains(order)) workOrders.add(order);
    }

    public boolean hasQrCode() {
        return qrCode != null;
    }

    public int countWorkOrders() {
        return workOrders.size();
    }

    public boolean hasOpenWorkOrders() {
        for (WorkOrder order : workOrders) {
            if (!order.isClosed()) return true;
        }
        return false;
    }

    public java.math.BigDecimal calculateTotalMaintenanceCost() {
        java.math.BigDecimal total = java.math.BigDecimal.ZERO;
        for (WorkOrder order : workOrders) {
            total = total.add(order.calculatePrice());
        }
        return total.setScale(2, java.math.RoundingMode.HALF_UP);
    }

    public java.util.Optional<MaintenanceHistory> findLatestHistory() {
        MaintenanceHistory latest = null;
        for (MaintenanceHistory history : maintenanceHistories) {
            if (latest == null || history.happenedAfter(latest)) latest = history;
        }
        return java.util.Optional.ofNullable(latest);
    }

    public boolean matchesSearchTerm(String term) {
        String normalizedTerm = term.toLowerCase(java.util.Locale.ROOT);
        return String.valueOf(equipmentId).equals(normalizedTerm)
                || name.toLowerCase(java.util.Locale.ROOT).contains(normalizedTerm)
                || serialNumber.toLowerCase(java.util.Locale.ROOT).contains(normalizedTerm);
    }

    @Override
    public String toString() {
        return "Equipment{" + "equipmentId=" + equipmentId + ", " + "name=" + name + ", " + "serialNumber=" + serialNumber + ", " + "location=" + location + ", " + "status=" + status + "}";
    }
}
