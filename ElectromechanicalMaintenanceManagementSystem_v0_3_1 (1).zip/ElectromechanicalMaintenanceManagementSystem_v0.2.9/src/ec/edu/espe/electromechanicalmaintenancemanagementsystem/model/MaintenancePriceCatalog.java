package ec.edu.espe.electromechanicalmaintenancemanagementsystem.model;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Standard service catalogue. Prices are illustrative USD estimates and can be adjusted.
 * POLYMORPHISM: the catalogue is a List of MaintenanceService (abstract type);
 * each element is a PreventiveService, CorrectiveService, DiagnosticService or
 * EmergencyService and answers getCategory(), getDefaultPriority() and describe()
 * in its own way.
 */
public final class MaintenancePriceCatalog {
    private static final List<MaintenanceService> SERVICES;

    static {
        List<MaintenanceService> services = new ArrayList<>();
        services.add(new CorrectiveService(1, "Run motor / motor rewinding (small motor)", "85.00"));
        services.add(new DiagnosticService(2, "Motor inspection and diagnosis", "25.00"));
        services.add(new PreventiveService(3, "Preventive maintenance of electric motor", "45.00"));
        services.add(new CorrectiveService(4, "Bearing replacement", "55.00"));
        services.add(new CorrectiveService(5, "Electrical wiring repair", "40.00"));
        services.add(new CorrectiveService(6, "Pump repair and maintenance", "65.00"));
        services.add(new PreventiveService(7, "Industrial fan maintenance", "50.00"));
        services.add(new DiagnosticService(8, "Control panel inspection", "35.00"));
        services.add(new CorrectiveService(9, "Contactor or relay replacement (labor)", "30.00"));
        services.add(new PreventiveService(10, "Generator maintenance", "90.00"));
        services.add(new DiagnosticService(11, "Alignment and vibration inspection", "60.00"));
        services.add(new EmergencyService(12, "Emergency technical visit", "75.00"));
        services.add(new PreventiveService(13, "Cleaning and lubrication", "20.00"));
        services.add(new DiagnosticService(14, "Insulation test", "35.00"));
        SERVICES = Collections.unmodifiableList(services);
    }

    private MaintenancePriceCatalog() { }

    public static List<MaintenanceService> getServices() {
        return SERVICES;
    }

    public static MaintenanceService getService(int index) {
        return SERVICES.get(index);
    }

    public static MaintenanceService findById(int serviceId) {
        for (MaintenanceService service : SERVICES) {
            if (service.getId() == serviceId) return service;
        }
        return null;
    }

    public static void showPrices() {
        System.out.println("\n===== MAINTENANCE SERVICE PRICE LIST (USD) =====");
        System.out.printf("%-4s %-12s %-45s %10s%n", "No.", "Category", "Service", "Price");
        System.out.println("--------------------------------------------------------------------------");
        for (int i = 0; i < SERVICES.size(); i++) {
            MaintenanceService service = SERVICES.get(i);
            System.out.printf("%-4d %-12s %-45s $%9s%s%n", i + 1, service.getCategory(),
                    service.getServiceName(), service.calculatePrice().toPlainString(),
                    service.requiresImmediateAttention() ? "  (!)" : "");
        }
        System.out.println("\nPrices are estimates in USD. Parts, materials and taxes may be charged separately.");
    }

    public static int chooseService(ConsoleInput input) {
        showPrices();
        return input.readIntInRange("Choose the maintenance service: ", 1, SERVICES.size()) - 1;
    }

    public static int serviceCount() {
        return SERVICES.size();
    }

    /** Catalogue ID of the service at the given zero-based index (IDs start at 1). */
    public static int serviceId(int index) {
        return SERVICES.get(index).getServiceId();
    }

    public static String serviceName(int index) {
        return SERVICES.get(index).getServiceName();
    }

    public static double servicePrice(int index) {
        return SERVICES.get(index).calculatePrice().doubleValue();
    }

    public static void save(Path directory) {
        List<Map<String, Object>> rows = new ArrayList<>();
        for (MaintenanceService service : SERVICES) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("serviceId", service.getServiceId());
            row.put("serviceName", service.getServiceName());
            row.put("serviceType", service.getClass().getSimpleName());
            row.put("category", service.getCategory());
            row.put("defaultPriority", service.getDefaultPriority());
            row.put("taskType", service.getTaskType());
            row.put("requiresImmediateAttention", service.requiresImmediateAttention());
            row.put("priceUSD", service.calculatePrice().doubleValue());
            rows.add(row);
        }
        new JsonFileManager(directory.resolve("service_catalog.json")).writeObjects(rows);
        Path csv = directory.resolve("service_catalog.csv");
        try {
            Files.createDirectories(directory);
            try (BufferedWriter writer = Files.newBufferedWriter(csv, StandardCharsets.UTF_8)) {
                writer.write("Service ID,Service Name,Service Type,Category,Default Priority,Task Type,Immediate Attention,Price USD");
                writer.newLine();
                for (MaintenanceService service : SERVICES) {
                    String name = service.getServiceName().replace("\"", "\"\"");
                    writer.write(service.getServiceId() + ",\"" + name + "\"," + service.getClass().getSimpleName()
                            + "," + service.getCategory() + "," + service.getDefaultPriority() + ","
                            + service.getTaskType() + "," + service.requiresImmediateAttention() + ","
                            + service.calculatePrice().toPlainString());
                    writer.newLine();
                }
            }
        } catch (IOException exception) {
            System.out.println("Could not export service catalogue CSV: " + exception.getMessage());
        }
    }
}
